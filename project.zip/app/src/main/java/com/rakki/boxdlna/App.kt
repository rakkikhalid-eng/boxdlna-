package com.rakki.boxdlna

import android.app.Application
import android.content.Context
import java.io.File
import java.io.PrintWriter
import java.io.StringWriter

class App : Application() {
    override fun onCreate() {
        super.onCreate()
        L.init(this)
        java.net.CookieHandler.setDefault(java.net.CookieManager(null, java.net.CookiePolicy.ACCEPT_ALL))
        Renderer.appCtx = this
        Renderer.ignoreStop = Cfg.ignoreStop(this)
        val prev = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            if (t !== android.os.Looper.getMainLooper().thread) {
                // a short background task failed: keep the app alive and leave a trace in the commands log
                try {
                    val top = e.stackTrace.take(3).joinToString(" < ") { it.className.substringAfterLast('.') + "." + it.methodName + ":" + it.lineNumber }
                    CmdLog.add("BACKGROUND ERROR (" + t.name + "): " + e.javaClass.simpleName + " " + (e.message ?: "").take(100) + " @ " + top)
                    val sw = StringWriter()
                    e.printStackTrace(PrintWriter(sw))
                    File(filesDir, "bgerror.txt").writeText("thread: " + t.name + "\n" + sw.toString())
                } catch (x: Throwable) { }
                return@setDefaultUncaughtExceptionHandler
            }
            try {
                val sw = StringWriter()
                e.printStackTrace(PrintWriter(sw))
                File(filesDir, "crash.txt").writeText("thread: " + t.name + "\n" + sw.toString())
                getSharedPreferences("box", Context.MODE_PRIVATE).edit().putBoolean("castOff", true).commit()
            } catch (x: Throwable) { }
            prev?.uncaughtException(t, e)
        }
    }
}
