package com.rakki.boxdlna

import androidx.media3.datasource.DefaultHttpDataSource
import java.net.URLDecoder

/**
 * HTTP settings shared by every player of the app. A sender cannot pass HTTP headers through DLNA, and many servers
 * answer 403 without a browser-like User-Agent / Referer, so the player starts plain and, if the server refuses
 * (401 / 403 / 429), retries with progressively more browser-like requests. Cookies are kept (see App).
 */
object Net {
    private const val UA_DESKTOP = "Mozilla/5.0 (Linux; Android 11; Box) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Safari/537.36"
    private const val UA_MOBILE = "Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36"

    /** Headers given by the sender (the "url|Referer=...&Cookie=..." convention or the /session API). */
    @Volatile var sessionHeaders: Map<String, String> = emptyMap()

    /** 0 = plain, 1 = Referer/Origin of the media's own site, 2 = same with a mobile browser identity. */
    @Volatile var profile = 0

    /** "https://host/x.m3u8|Referer=https://site/&User-Agent=..." -> (clean url, headers). */
    fun splitPipe(u: String): Pair<String, Map<String, String>> {
        val i = u.indexOf('|')
        if (i < 0) return u to emptyMap()
        val m = LinkedHashMap<String, String>()
        for (kv in u.substring(i + 1).split('&')) {
            val k = kv.substringBefore('=', "").trim()
            if (k.isNotEmpty()) m[k] = try { URLDecoder.decode(kv.substringAfter('=', ""), "UTF-8") } catch (e: Exception) { kv.substringAfter('=', "") }
        }
        return u.substring(0, i) to m
    }

    fun origin(u: String): String = Regex("^(https?://[^/]+)").find(u)?.groupValues?.get(1) ?: ""

    fun headers(url: String): Map<String, String> {
        val h = LinkedHashMap<String, String>()
        val o = origin(url)
        if (profile >= 1 && o.isNotEmpty()) { h["Referer"] = "$o/"; h["Origin"] = o }
        h.putAll(sessionHeaders)
        return h
    }

    fun userAgent(): String = sessionHeaders["User-Agent"] ?: if (profile >= 2) UA_MOBILE else UA_DESKTOP

    fun apply(f: DefaultHttpDataSource.Factory, url: String): DefaultHttpDataSource.Factory =
        f.setAllowCrossProtocolRedirects(true).setUserAgent(userAgent())
            .setConnectTimeoutMs(15000).setReadTimeoutMs(20000)
            .setDefaultRequestProperties(headers(url))

    fun factory(url: String): DefaultHttpDataSource.Factory = apply(DefaultHttpDataSource.Factory(), url)
}
