package com.rakki.boxdlna

import android.content.Context

/** Small settings store (OpenSubtitles API credentials). */
object Cfg {
    private fun p(c: Context) = c.getSharedPreferences("box", Context.MODE_PRIVATE)
    fun apiKey(c: Context): String = p(c).getString("osKey", "") ?: ""
    fun user(c: Context): String = p(c).getString("osUser", "") ?: ""
    fun pass(c: Context): String = p(c).getString("osPass", "") ?: ""
    fun ignoreStop(c: Context): Boolean = p(c).getBoolean("ignoreStop", false)
    fun setIgnoreStop(c: Context, v: Boolean) { p(c).edit().putBoolean("ignoreStop", v).apply() }
    // preferences applied automatically to every new video
    fun prefAudio(c: Context): String = p(c).getString("prefAudio", "") ?: ""
    fun setPrefAudio(c: Context, v: String) { p(c).edit().putString("prefAudio", v).apply() }
    fun prefSub(c: Context): String = p(c).getString("prefSub", "") ?: ""
    fun setPrefSub(c: Context, v: String) { p(c).edit().putString("prefSub", v).apply() }
    fun maxHeight(c: Context): Int = p(c).getInt("maxHeight", 0)
    fun setMaxHeight(c: Context, v: Int) { p(c).edit().putInt("maxHeight", v).apply() }

    // optional AI (speech recognition) used by the subtitle auto sync: any OpenAI-compatible /audio/transcriptions endpoint
    fun aiKey(c: Context): String = p(c).getString("aiKey", "") ?: ""
    fun aiBase(c: Context): String = (p(c).getString("aiBase", "") ?: "").ifEmpty { "https://api.openai.com/v1" }
    fun aiModel(c: Context): String = (p(c).getString("aiModel", "") ?: "").ifEmpty { "whisper-1" }
    fun saveAi(c: Context, key: String, base: String, model: String) {
        p(c).edit().putString("aiKey", key.trim()).putString("aiBase", base.trim().trimEnd('/')).putString("aiModel", model.trim()).apply()
    }
    fun aiBaseRaw(c: Context): String = p(c).getString("aiBase", "") ?: ""
    fun aiModelRaw(c: Context): String = p(c).getString("aiModel", "") ?: ""

    fun save(c: Context, key: String, user: String, pass: String) {
        p(c).edit().putString("osKey", key.trim()).putString("osUser", user.trim()).putString("osPass", pass).apply()
    }
}
