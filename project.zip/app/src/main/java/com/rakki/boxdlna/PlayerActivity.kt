package com.rakki.boxdlna

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.util.TypedValue
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.audio.AudioSink
import androidx.media3.exoplayer.audio.DefaultAudioSink
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.CaptionStyleCompat
import androidx.media3.ui.PlayerView
import java.util.Locale
import kotlin.math.abs

class PlayerActivity : Activity() {
    var player: ExoPlayer? = null
    private lateinit var view: PlayerView
    private lateinit var root: FrameLayout
    private lateinit var cueView: CueView
    private lateinit var panel: MenuPanel

    private var cues: List<CueParser.C> = emptyList()
        set(v) { field = v; Renderer.cueCount = v.size }
    private var subOffsetMs: Long
        get() = Renderer.subOffsetMs
        set(v) { Renderer.subOffsetMs = v }
    private var subsEnabled: Boolean
        get() = Renderer.subsEnabled
        set(v) { Renderer.subsEnabled = v }
    private var lastUri = ""
    private var loadedSig = ""
    private var gen = 0
    private var aspect = 0
    private var locked = false
    private var lastToast: Toast? = null

    private val speeds = listOf(0.5f, 0.75f, 1f, 1.25f, 1.5f, 2f)
    private var speedIdx = 2

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    // ---------------------------------------------------------------- tickers

    private val ticker = object : Runnable {
        override fun run() {
            player?.let { p ->
                Renderer.posMs = p.currentPosition
                val d = p.duration
                Renderer.durMs = if (d == C.TIME_UNSET) 0L else d
            }
            Renderer.main.postDelayed(this, 500)
        }
    }

    private val cueTick = object : Runnable {
        override fun run() {
            updateCue()
            if (hudVisible) updateHud()
            if (syncing) updateSyncStatus()
            Renderer.main.postDelayed(this, 100)
        }
    }

    private fun activeText(t: Long): String {
        var lo = 0
        var hi = cues.size - 1
        var idx = -1
        while (lo <= hi) {
            val mid = (lo + hi) ushr 1
            if (cues[mid].s <= t) { idx = mid; lo = mid + 1 } else hi = mid - 1
        }
        if (idx < 0) return ""
        val sb = StringBuilder()
        var i = maxOf(0, idx - 3)
        while (i <= idx) {
            if (cues[i].e > t) {
                if (sb.isNotEmpty()) sb.append('\n')
                sb.append(cues[i].t)
            }
            i++
        }
        return sb.toString()
    }

    private fun updateCue() {
        val p = player
        var txt = if (p == null || cues.isEmpty() || !subsEnabled) "" else activeText(p.currentPosition - subOffsetMs)
        if (txt.isEmpty() && panel.isOpen && (panel.tag == "style" || panel.tag == "subs")) txt = L.t("sample")
        if (txt != cueView.text) {
            cueView.text = txt
            cueView.invalidate()
        }
    }

    // ---------------------------------------------------------------- player events

    private val listener = object : Player.Listener {
        override fun onPlaybackStateChanged(playbackState: Int) { sync() }
        override fun onPlayWhenReadyChanged(playWhenReady: Boolean, reason: Int) { sync() }
        override fun onPlayerError(error: PlaybackException) {
            toast(L.t("player_error") + ": " + error.errorCodeName)
            Renderer.state = "STOPPED"
            Renderer.changed()
            Renderer.main.postDelayed({ finish() }, 3500)
        }
    }

    private fun sync() {
        val p = player ?: return
        val st = when (p.playbackState) {
            Player.STATE_BUFFERING -> "TRANSITIONING"
            Player.STATE_READY -> if (p.playWhenReady) "PLAYING" else "PAUSED_PLAYBACK"
            else -> "STOPPED"
        }
        if (Renderer.state != st) { Renderer.state = st; Renderer.changed() }
        if (p.playbackState == Player.STATE_ENDED) finish()
    }

    private fun toast(s: String) {
        lastToast?.cancel()
        lastToast = Toast.makeText(this, s, Toast.LENGTH_SHORT)
        lastToast?.show()
    }

    // ---------------------------------------------------------------- lifecycle

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        root = FrameLayout(this)
        root.setBackgroundColor(Color.BLACK)
        view = PlayerView(this)
        view.useController = false
        view.setShowBuffering(PlayerView.SHOW_BUFFERING_WHEN_PLAYING)
        root.addView(view, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        cueView = CueView(this)
        root.addView(cueView, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        setContentView(root)
        buildHud()
        panel = MenuPanel(this, root) { updateCue() }   // added last = drawn above the time bar
        aspect = SubStyle.aspect(this)
        applyStyle()
        root.post { applyAspect() }

        val http = DefaultHttpDataSource.Factory().setAllowCrossProtocolRedirects(true)
        val rf = object : DefaultRenderersFactory(this) {
            override fun buildAudioSink(
                context: Context, enableFloatOutput: Boolean, enableAudioTrackPlaybackParams: Boolean
            ): AudioSink = DefaultAudioSink.Builder(context)
                .setEnableFloatOutput(enableFloatOutput)
                .setEnableAudioTrackPlaybackParams(enableAudioTrackPlaybackParams)
                .setAudioProcessors(arrayOf(AutoSync.processor))
                .build()
        }.setEnableDecoderFallback(true)
        val p = ExoPlayer.Builder(this, rf)
            .setMediaSourceFactory(DefaultMediaSourceFactory(DefaultDataSource.Factory(this, http)))
            .build()
        p.addListener(listener)
        view.player = p
        player = p
        Renderer.activity = this
        Renderer.main.post(ticker)
        Renderer.main.post(cueTick)
        load(Renderer.wantPlay, takeStart())
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        onPlayRequest()
    }

    override fun onDestroy() {
        Renderer.main.removeCallbacks(ticker)
        Renderer.main.removeCallbacks(cueTick)
        Renderer.main.removeCallbacks(hideHud)
        Renderer.main.removeCallbacks(syncFinish)
        syncGen++
        AutoSync.collecting = false
        player?.release()
        player = null
        if (Renderer.activity === this) {
            Renderer.activity = null
            Renderer.wantPlay = false
            if (Renderer.uri.isNotEmpty()) Renderer.state = "STOPPED"
            Renderer.changed()
        }
        super.onDestroy()
    }

    private fun takeStart(): Long {
        val s = Renderer.startMs
        Renderer.startMs = 0
        return s
    }

    fun onPlayRequest() {
        val p = player ?: return
        if (Renderer.uri != lastUri) load(true, takeStart())
        else {
            // same video: if only the subtitle changed, reload it without restarting playback
            if (Renderer.signature() != loadedSig) reloadSubs()
            p.play()
        }
    }

    fun reloadSubs() {
        if (player == null) return
        loadedSig = Renderer.signature()
        Thread {
            val sub = Renderer.effectiveManual() ?: Renderer.subUrl?.let { SubtitleLoader.fetch(it, cacheDir) }
            val parsed = try { if (sub != null) CueParser.parse(sub.file.readText()) else emptyList() } catch (t: Throwable) { emptyList() }
            runOnUiThread { if (!isFinishing && !isDestroyed) cues = parsed }
        }.start()
    }

    private fun load(autoplay: Boolean, startMs: Long) {
        val u = Renderer.uri
        if (u.isEmpty()) { finish(); return }
        if (u != lastUri) { lastUri = u }
        refreshTitle()
        loadedSig = Renderer.signature()
        val g = ++gen
        Thread {
            val sub = Renderer.effectiveManual() ?: Renderer.subUrl?.let { SubtitleLoader.fetch(it, cacheDir) }
            val parsed = try { if (sub != null) CueParser.parse(sub.file.readText()) else emptyList() } catch (t: Throwable) { emptyList() }
            runOnUiThread {
                if (!isFinishing && !isDestroyed && g == gen) {
                    cues = parsed
                    start(u, autoplay, startMs)
                }
            }
        }.start()
    }

    private fun start(u: String, autoplay: Boolean, startMs: Long) {
        val p = player ?: return
        p.setMediaItem(MediaItem.fromUri(u), startMs)
        p.prepare()
        p.playWhenReady = autoplay
    }

    // ---------------------------------------------------------------- picture size

    private fun applyAspect() {
        val w = root.width
        val h = root.height
        if (w == 0 || h == 0) { root.post { applyAspect() }; return }
        var lp = FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT, Gravity.CENTER)
        when (aspect) {
            0 -> view.resizeMode = AspectRatioFrameLayout.RESIZE_MODE_FIT
            1 -> view.resizeMode = AspectRatioFrameLayout.RESIZE_MODE_ZOOM
            2 -> view.resizeMode = AspectRatioFrameLayout.RESIZE_MODE_FILL
            else -> {
                val r = if (aspect == 3) 16f / 9f else 4f / 3f
                var bw = w
                var bh = (w / r).toInt()
                if (bh > h) { bh = h; bw = (h * r).toInt() }
                lp = FrameLayout.LayoutParams(bw, bh, Gravity.CENTER)
                view.resizeMode = AspectRatioFrameLayout.RESIZE_MODE_FILL
            }
        }
        view.layoutParams = lp
    }

    private fun setAspect(i: Int) {
        aspect = ((i % 5) + 5) % 5
        SubStyle.setAspect(this, aspect)
        applyAspect()
    }

    // ---------------------------------------------------------------- subtitle style / sync

    fun applyStyle() {
        val st = SubStyle.get(this)
        cueView.sizeSp = st.size
        cueView.fillColor = st.color
        cueView.bgArgb = SubStyle.bgArgb(st)
        cueView.outline = st.edge
        cueView.bottomFraction = st.pos / 100f
        cueView.invalidate()
        view.subtitleView?.apply {
            setApplyEmbeddedStyles(false)
            setApplyEmbeddedFontSizes(false)
            setFixedTextSize(TypedValue.COMPLEX_UNIT_SP, st.size)
            setBottomPaddingFraction(st.pos / 100f)
            setStyle(
                CaptionStyleCompat(
                    st.color, SubStyle.bgArgb(st), Color.TRANSPARENT,
                    if (st.edge) CaptionStyleCompat.EDGE_TYPE_OUTLINE else CaptionStyleCompat.EDGE_TYPE_NONE,
                    Color.BLACK, null
                )
            )
        }
    }

    private fun offsetText(): String = String.format(Locale.US, "%+.1f %s", subOffsetMs / 1000.0, L.t("sec"))

    private fun nudge(ms: Long) {
        subOffsetMs = (subOffsetMs + ms).coerceIn(-600_000L, 600_000L)
        updateCue()
    }

    private fun snapNearest() {
        val p = player ?: return
        if (cues.isEmpty()) { toast(L.t("no_subs")); return }
        val t = p.currentPosition - subOffsetMs
        var best = cues[0]
        var bd = Long.MAX_VALUE
        for (c in cues) {
            val d = abs(c.s - t)
            if (d < bd) { bd = d; best = c }
        }
        subOffsetMs = p.currentPosition - best.s
        updateCue()
        toast(L.t("synced") + ": " + offsetText())
    }

    // ---- automatic sync (audio energy vs subtitle timing)

    private var syncing = false
    private var syncStartAt = 0L
    private var syncMode = 0 // 1 = fast offline scan (video paused), 2 = real-time listening
    private var syncGen = 0
    private val syncFinish = Runnable { finishAutoSync() }

    fun autoSync() = startAutoSync()

    private fun startAutoSync() {
        val p = player ?: return
        if (syncing) { toast(L.t("sync_busy")); return }
        if (cues.isEmpty()) { toast(L.t("no_subs")); return }
        syncing = true
        syncMode = 1
        syncStartAt = System.currentTimeMillis()
        val wasPlaying = p.playWhenReady
        val startMs = p.currentPosition
        val g = ++syncGen
        p.pause()                       // video stays paused while the audio is analysed
        panel.close()
        statusTv.text = "⏳  " + L.t("sync_scan")
        statusTv.visibility = View.VISIBLE
        val uri = Renderer.uri
        val cs = cues
        Thread {
            val bins = AudioScan.scan(uri, startMs, 90_000) { g != syncGen || isFinishing || isDestroyed }
            val r = if (bins != null) AutoSync.solve(bins, startMs, cs) else null
            runOnUiThread {
                if (g != syncGen || isFinishing || isDestroyed) return@runOnUiThread
                if (bins == null) {
                    // codec unsupported / stream not seekable: fall back to listening while playing
                    startRealtimeSync(wasPlaying)
                } else {
                    syncing = false
                    statusTv.visibility = View.GONE
                    if (r != null && r.ok) {
                        subOffsetMs = r.offsetMs.coerceIn(-600_000L, 600_000L)
                        updateCue()
                        toast(L.t("synced") + ": " + offsetText())
                    } else toast(L.t("sync_fail"))
                    if (wasPlaying) player?.play()
                }
            }
        }.start()
    }

    private fun startRealtimeSync(@Suppress("UNUSED_PARAMETER") wasPlaying: Boolean) {
        val p = player ?: return
        syncMode = 2
        syncStartAt = System.currentTimeMillis()
        AutoSync.begin(p.currentPosition)
        p.seekTo(p.currentPosition)   // flush so the audio tap starts exactly at this position
        p.play()
        toast(L.t("sync_start"))
        Renderer.main.postDelayed(syncFinish, 60_000)
    }

    private fun abortSync() {
        if (!syncing) return
        syncing = false
        syncGen++
        AutoSync.collecting = false
        Renderer.main.removeCallbacks(syncFinish)
        statusTv.visibility = View.GONE
    }

    private fun updateSyncStatus() {
        if (syncMode == 2) {
            val left = maxOf(0, 60 - ((System.currentTimeMillis() - syncStartAt) / 1000).toInt())
            statusTv.text = "⏱  " + L.t("autosync") + "  " + left + L.t("sec")
        }
    }

    private fun finishAutoSync() {
        if (!syncing) return
        syncing = false
        statusTv.visibility = View.GONE
        val bins = AutoSync.end()
        val start = AutoSync.refMs
        val cs = cues
        Thread {
            val r = AutoSync.solve(bins, start, cs)
            runOnUiThread {
                if (isFinishing || isDestroyed) return@runOnUiThread
                when {
                    bins.isEmpty() -> toast(L.t("sync_noaudio"))
                    r.ok -> {
                        subOffsetMs = r.offsetMs.coerceIn(-600_000L, 600_000L)
                        updateCue()
                        toast(L.t("synced") + ": " + offsetText())
                    }
                    else -> toast(L.t("sync_fail"))
                }
            }
        }.start()
    }

    // ---------------------------------------------------------------- subtitle search

    private var results: List<SubSearch.Res> = emptyList()
    private var searchState = 0 // 1 loading, 2 done, 3 error
    private var searchErr = ""
    private var searchGen = 0
    private var query: SubSearch.Q? = null

    private fun searchLang(): Int = getSharedPreferences("box", MODE_PRIVATE).getInt("searchLang", 0).coerceIn(0, 2)

    private fun needsFiles(): Boolean =
        Build.VERSION.SDK_INT >= 30 && !Environment.isExternalStorageManager()

    private fun startSearch(online: Boolean) {
        val g = ++searchGen
        searchState = 1
        results = emptyList()
        searchErr = ""
        val q = SubSearch.current()
        query = q
        Thread {
            var res: List<SubSearch.Res> = emptyList()
            var st = 2
            var err = ""
            try {
                if (online) {
                    if (q == null) { st = 3; err = L.t("no_title") } else res = SubSearch.searchOnline(this, q, searchLang())
                } else res = SubSearch.searchLocal(this, q)
            } catch (t: Throwable) { st = 3; err = L.t("net_error") }
            runOnUiThread {
                if (g == searchGen && !isFinishing && !isDestroyed) {
                    results = res; searchState = st; searchErr = err
                    if (panel.isOpen) panel.render()
                }
            }
        }.start()
    }

    private fun pick(r: SubSearch.Res) {
        toast(L.t("downloading"))
        val f = r.file
        Thread {
            var sub: SubtitleLoader.Sub? = null
            try {
                sub = if (f != null) SubtitleLoader.normalize(f.readBytes(), cacheDir, "manual")
                else SubSearch.download(this, r, cacheDir)
            } catch (t: Throwable) { }
            runOnUiThread {
                if (isFinishing || isDestroyed) return@runOnUiThread
                if (sub == null) toast(L.t("sub_error"))
                else {
                    Renderer.applyManual(sub)
                    toast(L.t("applied"))
                    panel.close()
                }
            }
        }.start()
    }

    // ---------------------------------------------------------------- menu pages

    private val textColors = listOf(
        "#FFFFFF" to "c_white", "#FFFF00" to "c_yellow", "#00FFFF" to "c_cyan",
        "#00FF00" to "c_green", "#FFA500" to "c_orange", "#CCCCCC" to "c_lgray"
    ).map { Color.parseColor(it.first) to it.second }

    private val bgColors = listOf(
        "#000000" to "c_black", "#333333" to "c_dgray", "#0D47A1" to "c_blue",
        "#FFFFFF" to "c_white", "#B71C1C" to "c_dred"
    ).map { Color.parseColor(it.first) to it.second }

    private fun cname(c: Int, pal: List<Pair<Int, String>>): String =
        pal.firstOrNull { (it.first and 0xFFFFFF) == (c and 0xFFFFFF) }?.second?.let { L.t(it) } ?: L.t("custom")

    private fun cycle(c: Int, pal: List<Pair<Int, String>>, d: Int): Int {
        val step = if (d == 0) 1 else d
        val i = pal.indexOfFirst { (it.first and 0xFFFFFF) == (c and 0xFFFFFF) }
        val n = if (i < 0) 0 else (i + step + pal.size) % pal.size
        return pal[n].first
    }

    private fun edit(f: (SubStyle.S) -> SubStyle.S) {
        val n = f(SubStyle.get(this))
        SubStyle.save(this, n.size, n.color, n.bg, n.opacity, n.pos, n.edge)
        applyStyle()
    }

    private fun rootPage() = MenuPanel.Page("root", { L.t("options") }, {
        listOf(
            MenuPanel.Item("⚙", { L.t("settings") }, null, true) { panel.push(settingsPage()) },
            MenuPanel.Item("CC", { L.t("subtitles") }, null, true) { panel.push(subsPage()) },
            MenuPanel.Item("🔒", { L.t(if (locked) "unlock" else "lock") }, { L.t(if (locked) "on" else "off") }, false) {
                locked = !locked
                toast(L.t(if (locked) "locked_t" else "unlocked_t"))
            },
            MenuPanel.Item("⏹", { L.t("stop") }) { d -> if (d == 0) Renderer.stop() }
        )
    })

    private fun settingsPage() = MenuPanel.Page("settings", { L.t("settings") }, {
        listOf(
            MenuPanel.Item("▭", { L.t("aspect") }, { L.t("asp$aspect") }) { d -> setAspect(aspect + (if (d == 0) 1 else d)) },
            MenuPanel.Item("⏩", { L.t("speed") }, { String.format(Locale.US, "x%.2f", speeds[speedIdx]).trimEnd('0').trimEnd('.') }) { d ->
                speedIdx = (speedIdx + (if (d == 0) 1 else d) + speeds.size) % speeds.size
                player?.setPlaybackSpeed(speeds[speedIdx])
            },
            MenuPanel.Item("🌐", { L.t("language") }, { L.nativeNames[L.idx] }) { d ->
                L.set(this, L.idx + (if (d == 0) 1 else d))
                refreshTitle()
            },
            MenuPanel.Item("⏻", { L.t("quit") }) { d -> if (d == 0) AppQuit.quit(this) }
        )
    })

    private fun subsPage() = MenuPanel.Page("subs", { L.t("subtitles") }, {
        listOf(
            MenuPanel.Item("🔍", { L.t("search_box") }, null, true) { panel.push(searchPage(false)) },
            MenuPanel.Item("☁", { L.t("search_online") }, { "OpenSubtitles" }, true) { panel.push(searchPage(true)) },
            MenuPanel.Item("🈯", { L.t("search_lang") }, { L.t("lang_" + SubSearch.langIds[searchLang()]) }) { d ->
                val n = (searchLang() + (if (d == 0) 1 else d) + 3) % 3
                getSharedPreferences("box", MODE_PRIVATE).edit().putInt("searchLang", n).apply()
            },
            MenuPanel.Item("CC", { L.t("subs_show") }, { L.t(if (subsEnabled) "on" else "off") }) { subsEnabled = !subsEnabled },
            MenuPanel.Item("⏱", { L.t("delay") }, { offsetText() }) { d ->
                if (d == 0) { subOffsetMs = 0; updateCue() } else nudge(d * 100L)
            },
            MenuPanel.Item("◎", { L.t("quicksync") }) { d -> if (d == 0) snapNearest() },
            MenuPanel.Item("✨", { L.t("autosync") }) { d -> if (d == 0) startAutoSync() },
            MenuPanel.Item("Aa", { L.t("appearance") }, null, true) { panel.push(stylePage()) }
        )
    })

    private fun stylePage() = MenuPanel.Page("style", { L.t("appearance") }, {
        listOf(
            MenuPanel.Item("Aa", { L.t("font_size") }, { SubStyle.get(this).size.toInt().toString() }) { d ->
                edit { it.copy(size = (it.size + 2 * (if (d == 0) 1 else d)).coerceIn(14f, 70f)) }
            },
            MenuPanel.Item("●", { L.t("font_color") }, { cname(SubStyle.get(this).color, textColors) }) { d ->
                edit { it.copy(color = cycle(it.color, textColors, d)) }
            },
            MenuPanel.Item("■", { L.t("bg_color") }, { cname(SubStyle.get(this).bg, bgColors) }) { d ->
                edit { it.copy(bg = cycle(it.bg, bgColors, d)) }
            },
            MenuPanel.Item("◐", { L.t("bg_opacity") }, {
                val o = SubStyle.get(this).opacity
                if (o == 0) L.t("transparent") else "$o%"
            }) { d -> edit { it.copy(opacity = (it.opacity + 10 * (if (d == 0) 1 else d)).coerceIn(0, 100)) } },
            MenuPanel.Item("↕", { L.t("height") }, { SubStyle.get(this).pos.toString() + "%" }) { d ->
                edit { it.copy(pos = (it.pos + 2 * (if (d == 0) 1 else d)).coerceIn(0, 60)) }
            },
            MenuPanel.Item("▢", { L.t("outline") }, { L.t(if (SubStyle.get(this).edge) "on" else "off") }) { d ->
                edit { it.copy(edge = if (d == 0) !it.edge else d > 0) }
            },
            MenuPanel.Item("↺", { L.t("reset_style") }) { d -> if (d == 0) { SubStyle.reset(this); applyStyle() } }
        )
    })

    private fun searchPage(online: Boolean) = MenuPanel.Page(
        if (online) "online" else "box",
        { L.t(if (online) "search_online" else "search_box") },
        {
            val items = ArrayList<MenuPanel.Item>()
            val q = query
            if (q != null) items.add(MenuPanel.Item("🎬", { q.display() }) { })
            if (online) items.add(MenuPanel.Item("☁", { L.t(if (Cfg.apiKey(this).isNotEmpty()) "src_api" else "src_free") }) { })
            when {
                searchState == 1 -> items.add(MenuPanel.Item("⏳", { L.t("searching") }) { })
                searchState == 3 -> items.add(MenuPanel.Item("⚠", { searchErr }) { })
                results.isEmpty() -> items.add(MenuPanel.Item("∅", { L.t(if (!online && needsFiles()) "no_perm" else "no_results") }) { })
                else -> for (r in results) items.add(MenuPanel.Item("CC", { r.label + "\n" + r.info }) { d -> if (d == 0) pick(r) })
            }
            items
        },
        { startSearch(online) }
    )

    private fun openMenu() {
        hideHudNow()
        panel.open(rootPage())
        updateCue()
    }

    // ---------------------------------------------------------------- time bar + center buttons (HUD)

    private inner class SeekView(ctx: Context) : View(ctx) {
        var frac = 0f
        private val p = Paint(Paint.ANTI_ALIAS_FLAG)
        override fun onDraw(c: Canvas) {
            val w = width.toFloat()
            val h = height.toFloat()
            val cy = h / 2
            val tr = h * 0.13f
            p.color = 0x66FFFFFF
            c.drawRoundRect(0f, cy - tr, w, cy + tr, tr, tr, p)
            p.color = MenuPanel.ACCENT
            c.drawRoundRect(0f, cy - tr, w * frac, cy + tr, tr, tr, p)
            p.color = Color.WHITE
            c.drawCircle(w * frac, cy, h * 0.3f, p)
        }
    }

    private lateinit var hudBottom: LinearLayout
    private lateinit var hudTop: LinearLayout
    private lateinit var hudCenter: LinearLayout
    private lateinit var seekView: SeekView
    private lateinit var tvPos: TextView
    private lateinit var tvDur: TextView
    private lateinit var tvTitle: TextView
    private lateinit var tvYear: TextView
    private lateinit var statusTv: TextView
    private val centerBtns = ArrayList<TextView>()
    private var hudVisible = false
    private var controlsMode = false
    private var focusIdx = 1
    private val hideHud = Runnable { hideHudNow() }

    private fun fmt(ms: Long): String {
        val s = maxOf(0L, ms) / 1000
        return if (s >= 3600) String.format(Locale.US, "%d:%02d:%02d", s / 3600, (s % 3600) / 60, s % 60)
        else String.format(Locale.US, "%02d:%02d", s / 60, s % 60)
    }

    private fun gradient(top: Boolean): GradientDrawable {
        val g = GradientDrawable(
            if (top) GradientDrawable.Orientation.TOP_BOTTOM else GradientDrawable.Orientation.BOTTOM_TOP,
            intArrayOf(Color.parseColor("#D9000000"), Color.TRANSPARENT)
        )
        return g
    }

    private fun txt(s: String, size: Float, color: Int, bold: Boolean = false): TextView {
        val t = TextView(this)
        t.text = s
        t.textSize = size
        t.setTextColor(color)
        if (bold) t.setTypeface(t.typeface, Typeface.BOLD)
        return t
    }

    private fun buildHud() {
        // bottom: time + progress
        hudBottom = LinearLayout(this)
        hudBottom.orientation = LinearLayout.HORIZONTAL
        hudBottom.gravity = Gravity.CENTER_VERTICAL
        hudBottom.layoutDirection = View.LAYOUT_DIRECTION_LTR
        hudBottom.background = gradient(false)
        hudBottom.setPadding(dp(28), dp(36), dp(28), dp(22))
        hudBottom.visibility = View.GONE
        tvPos = txt("00:00", 16f, Color.WHITE)
        tvDur = txt("00:00", 16f, Color.WHITE)
        seekView = SeekView(this)
        hudBottom.addView(tvPos)
        val slp = LinearLayout.LayoutParams(0, dp(26), 1f)
        slp.leftMargin = dp(14); slp.rightMargin = dp(14)
        hudBottom.addView(seekView, slp)
        hudBottom.addView(tvDur)
        root.addView(hudBottom, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM))

        // top: back, title, menu
        hudTop = LinearLayout(this)
        hudTop.orientation = LinearLayout.HORIZONTAL
        hudTop.gravity = Gravity.CENTER_VERTICAL
        hudTop.layoutDirection = View.LAYOUT_DIRECTION_LTR
        hudTop.background = gradient(true)
        hudTop.setPadding(dp(20), dp(14), dp(20), dp(30))
        hudTop.visibility = View.GONE
        val back = txt("←", 28f, Color.WHITE)
        back.setPadding(dp(8), 0, dp(18), 0)
        back.setOnClickListener { finish() }
        val titles = LinearLayout(this)
        titles.orientation = LinearLayout.VERTICAL
        tvTitle = txt("", 22f, Color.WHITE, true)
        tvTitle.maxLines = 1
        tvTitle.ellipsize = android.text.TextUtils.TruncateAt.END
        tvYear = txt("", 16f, Color.parseColor("#C7CEDB"), true)
        titles.addView(tvTitle)
        titles.addView(tvYear)
        val menuBtn = txt("☰", 26f, Color.WHITE)
        menuBtn.setPadding(dp(18), 0, dp(8), 0)
        menuBtn.setOnClickListener { openMenu() }
        hudTop.addView(back)
        hudTop.addView(titles, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        hudTop.addView(menuBtn)
        root.addView(hudTop, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP))

        // center: rewind / play-pause / forward (only after OK)
        hudCenter = LinearLayout(this)
        hudCenter.orientation = LinearLayout.HORIZONTAL
        hudCenter.layoutDirection = View.LAYOUT_DIRECTION_LTR
        hudCenter.visibility = View.GONE
        val labels = listOf("« 10", "▶", "10 »")
        for ((i, s) in labels.withIndex()) {
            val b = txt(s, if (i == 1) 30f else 20f, Color.WHITE, true)
            b.gravity = Gravity.CENTER
            b.isClickable = true
            b.setOnClickListener { focusIdx = i; activateFocus() }
            val lp = LinearLayout.LayoutParams(dp(if (i == 1) 84 else 68), dp(if (i == 1) 84 else 68))
            lp.setMargins(dp(14), 0, dp(14), 0)
            lp.gravity = Gravity.CENTER_VERTICAL
            hudCenter.addView(b, lp)
            centerBtns.add(b)
        }
        root.addView(hudCenter, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER))

        // sync status (top center)
        statusTv = txt("", 16f, Color.WHITE, true)
        statusTv.setPadding(dp(16), dp(8), dp(16), dp(8))
        val sg = GradientDrawable()
        sg.setColor(Color.parseColor("#CC1B1D26"))
        sg.cornerRadius = dp(20).toFloat()
        statusTv.background = sg
        statusTv.visibility = View.GONE
        val slp2 = FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP or Gravity.CENTER_HORIZONTAL)
        slp2.topMargin = dp(18)
        root.addView(statusTv, slp2)
    }

    private fun refreshTitle() {
        val q = SubSearch.current()
        tvTitle.text = q?.title ?: ""
        tvYear.text = q?.year ?: ""
        tvYear.visibility = if (tvYear.text.isEmpty()) View.GONE else View.VISIBLE
    }

    private fun showHud(controls: Boolean) {
        hudVisible = true
        if (controls) controlsMode = true
        applyHudVisibility()
        updateHud()
        Renderer.main.removeCallbacks(hideHud)
        Renderer.main.postDelayed(hideHud, if (controlsMode) 6000 else 3000)
    }

    private fun hideHudNow() {
        Renderer.main.removeCallbacks(hideHud)
        hudVisible = false
        controlsMode = false
        applyHudVisibility()
    }

    private fun applyHudVisibility() {
        hudBottom.visibility = if (hudVisible) View.VISIBLE else View.GONE
        val c = if (hudVisible && controlsMode) View.VISIBLE else View.GONE
        hudTop.visibility = c
        hudCenter.visibility = c
    }

    private fun updateHud() {
        val p = player ?: return
        val d = p.duration
        val dur = if (d == C.TIME_UNSET) 0L else d
        val pos = p.currentPosition
        tvPos.text = fmt(pos)
        tvDur.text = fmt(dur)
        seekView.frac = if (dur > 0) (pos.toFloat() / dur).coerceIn(0f, 1f) else 0f
        seekView.invalidate()
        if (controlsMode) {
            centerBtns[1].text = if (p.playWhenReady) "❚❚" else "▶"
            for ((i, b) in centerBtns.withIndex()) {
                val g = GradientDrawable()
                g.shape = GradientDrawable.OVAL
                if (i == focusIdx) { g.setColor(Color.WHITE); b.setTextColor(Color.parseColor("#111827")) }
                else { g.setColor(Color.parseColor("#99000000")); g.setStroke(dp(2), Color.parseColor("#88FFFFFF")); b.setTextColor(Color.WHITE) }
                b.background = g
            }
        }
    }

    private fun togglePlay() {
        val p = player ?: return
        if (p.playWhenReady) p.pause() else p.play()
    }

    private fun activateFocus() {
        when (focusIdx) {
            0 -> seekBy(-10_000)
            1 -> togglePlay()
            2 -> seekBy(10_000)
        }
        showHud(true)
    }

    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        if (panel.isOpen) {
            if (ev.action == MotionEvent.ACTION_UP && ev.x < panel.left) { panel.close(); return true }
            return super.dispatchTouchEvent(ev)
        }
        if (locked) {
            if (ev.action == MotionEvent.ACTION_UP) toast(L.t("locked_t"))
            return true
        }
        val r = super.dispatchTouchEvent(ev)
        if (ev.action == MotionEvent.ACTION_UP) showHud(true)
        return r
    }

    // ---------------------------------------------------------------- remote control

    private fun seekBy(ms: Long) {
        val p = player ?: return
        if (syncing) abortSync()
        val d = p.duration
        var t = p.currentPosition + ms
        if (t < 0) t = 0
        if (d != C.TIME_UNSET && t > d - 1000) t = maxOf(d - 1000, 0L)
        p.seekTo(t)
    }

    private val panelKeys = setOf(
        KeyEvent.KEYCODE_DPAD_UP, KeyEvent.KEYCODE_DPAD_DOWN, KeyEvent.KEYCODE_DPAD_LEFT,
        KeyEvent.KEYCODE_DPAD_RIGHT, KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER,
        KeyEvent.KEYCODE_BACK, KeyEvent.KEYCODE_MENU
    )

    private val playerKeys = setOf(
        KeyEvent.KEYCODE_DPAD_LEFT, KeyEvent.KEYCODE_DPAD_RIGHT, KeyEvent.KEYCODE_DPAD_UP,
        KeyEvent.KEYCODE_DPAD_DOWN, KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER,
        KeyEvent.KEYCODE_MENU, KeyEvent.KEYCODE_SETTINGS, KeyEvent.KEYCODE_MEDIA_FAST_FORWARD,
        KeyEvent.KEYCODE_MEDIA_REWIND, KeyEvent.KEYCODE_PROG_RED, KeyEvent.KEYCODE_PROG_GREEN,
        KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE, KeyEvent.KEYCODE_MEDIA_PLAY, KeyEvent.KEYCODE_MEDIA_PAUSE
    )

    override fun dispatchKeyEvent(e: KeyEvent): Boolean {
        val k = e.keyCode
        if (panel.isOpen) {
            if (k !in panelKeys) return super.dispatchKeyEvent(e)
            if (e.action == KeyEvent.ACTION_DOWN) panel.key(k)
            return true
        }
        if (k == KeyEvent.KEYCODE_BACK && hudVisible && controlsMode) {
            if (e.action == KeyEvent.ACTION_DOWN) hideHudNow()
            return true
        }
        if (k !in playerKeys) return super.dispatchKeyEvent(e)
        if (e.action == KeyEvent.ACTION_DOWN) playerKey(k)
        return true
    }

    private fun playerKey(k: Int) {
        val p = player ?: return
        val inControls = hudVisible && controlsMode
        when (k) {
            KeyEvent.KEYCODE_DPAD_LEFT -> {
                if (inControls) { focusIdx = maxOf(0, focusIdx - 1); showHud(true) }
                else { seekBy(-10_000); showHud(false) }
            }
            KeyEvent.KEYCODE_DPAD_RIGHT -> {
                if (inControls) { focusIdx = minOf(2, focusIdx + 1); showHud(true) }
                else { seekBy(10_000); showHud(false) }
            }
            KeyEvent.KEYCODE_MEDIA_REWIND -> { seekBy(-10_000); showHud(inControls) }
            KeyEvent.KEYCODE_MEDIA_FAST_FORWARD -> { seekBy(10_000); showHud(inControls) }
            KeyEvent.KEYCODE_DPAD_UP, KeyEvent.KEYCODE_MENU, KeyEvent.KEYCODE_SETTINGS -> openMenu()
            KeyEvent.KEYCODE_DPAD_DOWN -> showHud(inControls)   // no longer changes the picture size
            KeyEvent.KEYCODE_PROG_RED -> { nudge(-500); toast(L.t("delay").substringBefore(" (") + ": " + offsetText()) }
            KeyEvent.KEYCODE_PROG_GREEN -> { nudge(500); toast(L.t("delay").substringBefore(" (") + ": " + offsetText()) }
            KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE -> { togglePlay(); showHud(inControls) }
            KeyEvent.KEYCODE_MEDIA_PLAY -> { p.play(); showHud(inControls) }
            KeyEvent.KEYCODE_MEDIA_PAUSE -> { p.pause(); showHud(inControls) }
            KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER -> {
                if (inControls) activateFocus()
                else { togglePlay(); focusIdx = 1; showHud(true) }
            }
        }
    }
}
