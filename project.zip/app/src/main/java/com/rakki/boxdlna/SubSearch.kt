package com.rakki.boxdlna

import android.content.Context
import android.os.Environment
import org.json.JSONArray
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLDecoder
import java.net.URLEncoder
import java.util.zip.GZIPInputStream

/** Finds subtitles on the box's storage and on OpenSubtitles, using the title sent by the phone. */
object SubSearch {
    class Q(val title: String, val name: String, val year: String, val season: Int, val episode: Int) {
        fun display(): String {
            var s = title
            if (year.isNotEmpty()) s += " ($year)"
            if (season > 0) s += " S%02dE%02d".format(season, episode)
            return s
        }
    }

    class Res(val label: String, val info: String, val file: File?, val url: String?)

    /** ISO 639-2 codes used by OpenSubtitles, in the order shown in the menu. */
    val langIds = listOf("ara", "fre", "eng")

    // ------------------------------------------------------------------ title

    private val DC_TITLE = Regex("""<dc:title[^>]*>(.*?)</dc:title>""", setOf(RegexOption.DOT_MATCHES_ALL))
    private val SEASON = Regex("""[Ss](\d{1,2})[ ._-]?[Ee](\d{1,3})|(?<!\d)(\d{1,2})x(\d{2,3})(?!\d)""")
    private val YEAR = Regex("""(?<!\d)((?:19|20)\d{2})(?!\d)""")
    private val QUALITY = Regex(
        """(?i)\b(480p|576p|720p|1080p|2160p|4k|bluray|blu-ray|brrip|bdrip|webrip|web-dl|webdl|hdrip|hdtv|dvdrip|x264|x265|h264|h265|hevc|multi|vostfr|truefrench|vff|vfq)\b"""
    )

    fun rawTitle(): String {
        val m = DC_TITLE.find(Renderer.meta)
        if (m != null) {
            val t = unesc(m.groupValues[1]).trim()
            if (t.isNotEmpty()) return t
        }
        val u = Renderer.uri.substringBefore('?').substringAfterLast('/')
        return try { URLDecoder.decode(u, "UTF-8") } catch (e: Exception) { u }
    }

    fun current(): Q? {
        val raw = rawTitle()
        if (raw.isBlank()) return null
        return parse(raw)
    }

    fun parse(raw0: String): Q {
        var raw = raw0.trim()
        raw = raw.replace(Regex("""(?i)\.(mkv|mp4|avi|mov|m4v|wmv|flv|webm|ts|mpg|mpeg|srt|ass|vtt)$"""), "")
        val s = raw.replace(Regex("""[._\[\]()]+"""), " ").replace(Regex("""\s+"""), " ").trim()
        var season = 0
        var episode = 0
        var cut = s.length
        val sm = SEASON.find(s)
        if (sm != null) {
            if (sm.groupValues[1].isNotEmpty()) {
                season = sm.groupValues[1].toInt(); episode = sm.groupValues[2].toInt()
            } else {
                season = sm.groupValues[3].toInt(); episode = sm.groupValues[4].toInt()
            }
            cut = minOf(cut, sm.range.first)
        }
        var year = ""
        val ym = YEAR.find(s)
        if (ym != null && ym.range.first > 0) {
            year = ym.groupValues[1]
            cut = minOf(cut, ym.range.first)
        }
        val qm = QUALITY.find(s)
        if (qm != null && qm.range.first > 0) cut = minOf(cut, qm.range.first)
        var title = s.substring(0, cut).trim(' ', '-', ':')
        if (title.isEmpty()) title = s
        val name = title.lowercase().replace(Regex("""[^\p{L}\p{N} ]"""), " ").replace(Regex("""\s+"""), " ").trim()
        return Q(title, name, year, season, episode)
    }

    // ------------------------------------------------------------------ on the box

    private val EXT = setOf("srt", "vtt", "ass", "ssa")

    private fun roots(ctx: Context): List<File> {
        val out = LinkedHashSet<File>()
        val ext = Environment.getExternalStorageDirectory()
        for (d in listOf("Download", "Downloads", "Movies", "Subtitles", "Subs", "Documents", "Video", "Videos")) {
            out.add(File(ext, d))
        }
        out.add(ext)
        try {
            File("/storage").listFiles()?.forEach { v ->
                if (v.isDirectory && v.name != "self" && v.name != "emulated") {
                    out.add(v)
                    for (d in listOf("Subtitles", "Subs", "Movies", "Download")) out.add(File(v, d))
                }
            }
        } catch (e: Exception) { }
        ctx.getExternalFilesDir(null)?.let { out.add(it) }
        return out.filter { it.isDirectory }
    }

    private fun walk(dir: File, depth: Int, into: MutableList<File>, limit: Int) {
        if (into.size >= limit || depth < 0) return
        val kids = try { dir.listFiles() } catch (e: Exception) { null } ?: return
        for (f in kids) {
            if (into.size >= limit) return
            if (f.name.startsWith(".")) continue
            if (f.isDirectory) {
                if (f.name == "Android" || f.name == "cache") continue
                walk(f, depth - 1, into, limit)
            } else if (f.extension.lowercase() in EXT) into.add(f)
        }
    }

    fun searchLocal(ctx: Context, q: Q?): List<Res> {
        val found = ArrayList<File>()
        val seen = HashSet<String>()
        for (r in roots(ctx)) {
            val tmp = ArrayList<File>()
            walk(r, if (r == Environment.getExternalStorageDirectory()) 2 else 4, tmp, 4000)
            for (f in tmp) if (seen.add(f.absolutePath)) found.add(f)
        }
        val tokens = (q?.name ?: "").split(' ').filter { it.length > 1 }
        val scored = found.map { f ->
            val n = f.nameWithoutExtension.lowercase().replace(Regex("""[^\p{L}\p{N} ]"""), " ")
            var sc = tokens.count { n.contains(it) } * 10
            if (q != null && q.season > 0 && n.contains("s%02de%02d".format(q.season, q.episode))) sc += 15
            if (q != null && q.year.isNotEmpty() && n.contains(q.year)) sc += 3
            f to sc
        }
        val hit = if (tokens.isEmpty()) scored else scored.filter { it.second > 0 }
        return hit.sortedWith(compareByDescending<Pair<File, Int>> { it.second }.thenByDescending { it.first.lastModified() })
            .take(40)
            .map { (f, _) -> Res(f.name, f.parentFile?.name ?: "", f, null) }
    }

    // ------------------------------------------------------------------ OpenSubtitles

    fun searchOnline(q: Q, langId: String): List<Res> {
        val sb = StringBuilder("https://rest.opensubtitles.org/search")
        if (q.season > 0) sb.append("/episode-").append(q.episode)
        sb.append("/query-").append(URLEncoder.encode(q.name, "UTF-8").replace("+", "%20"))
        if (q.season > 0) sb.append("/season-").append(q.season)
        sb.append("/sublanguageid-").append(langId)
        val c = URL(sb.toString()).openConnection() as HttpURLConnection
        c.connectTimeout = 10000
        c.readTimeout = 15000
        c.setRequestProperty("User-Agent", "TemporaryUserAgent")
        val body = c.inputStream.use { it.readBytes() }.toString(Charsets.UTF_8)
        val arr = JSONArray(body)
        class Tmp(val r: Res, val dl: Int)
        val list = ArrayList<Tmp>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val link = o.optString("SubDownloadLink")
            if (link.isEmpty()) continue
            val fmt = o.optString("SubFormat").lowercase()
            if (fmt.isNotEmpty() && fmt !in EXT) continue
            val dl = o.optString("SubDownloadsCnt").toIntOrNull() ?: 0
            val movie = o.optString("MovieName")
            val year = o.optString("MovieYear")
            val info = "$movie $year  ⬇$dl".trim()
            list.add(Tmp(Res(o.optString("SubFileName"), info, null, link), dl))
        }
        return list.sortedByDescending { it.dl }.take(40).map { it.r }
    }

    fun download(url: String, dir: File): SubtitleLoader.Sub? {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 10000
        c.readTimeout = 20000
        c.instanceFollowRedirects = true
        c.setRequestProperty("User-Agent", "TemporaryUserAgent")
        val raw = c.inputStream.use { it.readBytes() }
        val bytes = if (url.endsWith(".gz") || (raw.size > 2 && raw[0] == 0x1f.toByte() && raw[1] == 0x8b.toByte()))
            GZIPInputStream(raw.inputStream()).use { it.readBytes() } else raw
        return SubtitleLoader.normalize(bytes, dir, "manual")
    }
}
