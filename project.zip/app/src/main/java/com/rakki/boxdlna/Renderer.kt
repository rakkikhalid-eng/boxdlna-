package com.rakki.boxdlna

import android.content.Context
import android.content.Intent
import android.os.Handler
import android.os.Looper

object Renderer {
    val main = Handler(Looper.getMainLooper())

    @Volatile var uri = ""
    @Volatile var meta = ""
    @Volatile var subUrl: String? = null
    @Volatile var state = "NO_MEDIA_PRESENT"
    @Volatile var posMs = 0L
    @Volatile var durMs = 0L
    @Volatile var wantPlay = false
    @Volatile var startMs = 0L
    @Volatile var activity: PlayerActivity? = null
    @Volatile var manual: SubtitleLoader.Sub? = null
    @Volatile var manualUri = ""
    @Volatile var onChange: (() -> Unit)? = null
    @Volatile var subOffsetMs = 0L
    @Volatile var subsEnabled = true
    @Volatile var cueCount = 0
    @Volatile var ovSeason = -1
    @Volatile var ovEpisode = -1
    @Volatile var ovYear: String? = null
    @Volatile var ovTitle: String? = null
    @Volatile var results: List<SubSearch.Res> = emptyList()
    @Volatile var ignoreStop = false
    @Volatile var appCtx: Context? = null
    @Volatile var activeSubPath = ""
    @Volatile var senderLang = ""
    @Volatile var sources: List<Didl.Src> = emptyList()
    @Volatile var extraSubs: List<Didl.ExtraSub> = emptyList()
    @Volatile var resumeKey = ""
    @Volatile var resumePos = 0L
    @Volatile var resumeAt = 0L

    /** URL without query string. */
    fun key(u: String): String = u.substringBefore('?')

    /**
     * Identity of a video independent of host and port: ClipBox restarts a local server on a new port every time
     * it re-sends the same movie, so the DIDL title + URL path identify it instead.
     */
    fun vkey(u: String, m: String): String {
        val t = Regex("<dc:title[^>]*>(.*?)</dc:title>", RegexOption.DOT_MATCHES_ALL).find(m)?.groupValues?.get(1)?.trim().orEmpty()
        val hostPath = u.substringBefore('?').substringAfter("://")
        return if (t.isNotEmpty()) t + "|/" + hostPath.substringAfter('/', "") else hostPath   // no title: host:port counts
    }

    fun videoKey(): String = vkey(uri, meta)

    fun rememberResume(pos: Long, key: String = videoKey()) {
        if (key.isNotEmpty() && pos > 5000) { resumeKey = key; resumePos = pos; resumeAt = System.currentTimeMillis() }
    }

    fun changed() { onChange?.invoke() }

    fun setUri(u: String, m: String) {
        val newSub = extractSubtitle(m)
        val (srcs, subs) = Didl.parse(m)
        sources = srcs
        if (subs.map { it.url } != extraSubs.map { it.url }) extraSubs = subs
        // Same video, player already running: only the subtitle changed -> swap it live, no restart.
        cancelPendingStop()
        CmdLog.add("SetURI " + u.take(200) + " | sub=" + (newSub ?: "-") + " | meta=" + m.take(500))
        val act = activity
        val alive = act != null && !act.isFinishing && !act.isDestroyed
        if (u.isNotEmpty() && alive && vkey(u, m) == videoKey()) {
            val urlChanged = key(u) != key(uri)       // new port / host: the old server may be gone
            uri = u
            meta = m
            if (newSub != subUrl) {
                subUrl = newSub
                manual = null
                manualUri = ""
                main.post { activity?.reloadSubs() }
            }
            if (urlChanged) main.post { activity?.switchSource() }
            changed()
            return
        }
        uri = u; meta = m
        subUrl = newSub
        posMs = 0; durMs = 0; wantPlay = false; startMs = 0
        // the sender re-sent the same video moments after it was closed (e.g. subtitle toggle): resume where it was
        if (u.isNotEmpty() && vkey(u, m) == resumeKey && System.currentTimeMillis() - resumeAt < 20_000) {
            startMs = resumePos
            CmdLog.add("resume at " + resumePos + " ms")
        }
        resumeKey = ""
        subOffsetMs = 0
        ovSeason = -1; ovEpisode = -1; ovYear = null; ovTitle = null
        activeSubPath = ""
        senderLang = ""
        if (u.isNotEmpty() && manualUri == "*") manualUri = u
        state = if (u.isEmpty()) "NO_MEDIA_PRESENT" else "STOPPED"
        main.post { activity?.player?.pause() }
        changed()
    }

    fun applyManual(s: SubtitleLoader.Sub, label: String = "") {
        val saved = SubHistory.save(appCtx, uri, s, label)
        manual = if (saved.isNotEmpty()) SubtitleLoader.Sub(java.io.File(saved), s.mime) else s
        activeSubPath = saved
        subOffsetMs = 0
        subsEnabled = true
        manualUri = if (uri.isNotEmpty() && activity != null) uri else "*"
        main.post { activity?.reloadSubs() }
    }

    /** Go back to the subtitle the sender app provided. */
    /** Switch to another announced quality of the same movie, keeping the position. */
    fun useSource(url: String) {
        uri = url
        main.post { activity?.switchSource() }
    }

    fun useSenderSub() {
        manual = null
        manualUri = ""
        activeSubPath = ""
        subsEnabled = true
        main.post { activity?.reloadSubs() }
    }

    fun effectiveManual(): SubtitleLoader.Sub? = manual?.takeIf { manualUri == uri }

    fun signature(): String = uri + "|" + (effectiveManual()?.file?.name ?: subUrl ?: "")

    fun play(ctx: Context) {
        if (uri.isEmpty()) return
        wantPlay = true
        if (state != "PLAYING") { state = "TRANSITIONING"; changed() }
        val a = activity
        if (a != null) main.post { a.onPlayRequest() }
        try {
            ctx.startActivity(Intent(ctx, PlayerActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (e: Exception) { }
    }

    fun pause() { main.post { activity?.player?.pause() } }

    private val stopRunnable = Runnable { stop() }

    /** Stop requested by the sender: wait a moment, because a re-send of the same video (subtitle change) cancels it. */
    fun stopSoon() {
        main.removeCallbacks(stopRunnable)
        main.postDelayed(stopRunnable, 1500)
    }

    fun cancelPendingStop() { main.removeCallbacks(stopRunnable) }

    fun stop() {
        main.removeCallbacks(stopRunnable)
        rememberResume(posMs)          // a re-send of the same movie within seconds resumes here
        wantPlay = false
        state = if (uri.isEmpty()) "NO_MEDIA_PRESENT" else "STOPPED"
        posMs = 0
        main.post { activity?.finish() }
        changed()
    }

    fun seek(ms: Long) {
        main.post {
            val p = activity?.player
            if (p != null) p.seekTo(ms) else startMs = ms   // player not created yet: use as start position
        }
    }
}
