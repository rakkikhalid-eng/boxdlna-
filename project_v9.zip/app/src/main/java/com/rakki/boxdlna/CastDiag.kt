package com.rakki.boxdlna

import java.util.Collections

/** Live status of the Cast receiver, shown on the home screen to debug discovery. */
object CastDiag {
    @Volatile var tls = "لم يبدأ"
    @Volatile var mdns = "لم يبدأ"
    @Volatile var conns = 0
    @Volatile var last = "-"
    val found: MutableSet<String> = Collections.synchronizedSet(LinkedHashSet<String>())

    private val lines = ArrayList<String>()

    fun log(s: String) {
        synchronized(lines) {
            lines.add(s)
            while (lines.size > 12) lines.removeAt(0)
        }
    }

    fun text(): String {
        val names = synchronized(found) { found.toList() }
        return tls + "\n" + mdns +
            "\nاتصالات من تطبيقات الإرسال: " + conns +
            "\nآخر رسالة وصلت: " + last +
            "\n— السجل —\n" + synchronized(lines) { lines.joinToString("\n") } +
            "\nأجهزة Cast ظاهرة على الشبكة: " + names.size +
            (if (names.isEmpty()) "" else "\n" + names.joinToString("، "))
    }
}
