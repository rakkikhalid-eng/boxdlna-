package com.rakki.boxdlna

import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import java.nio.ByteOrder
import kotlin.math.sqrt

/**
 * Decodes a window of the movie's audio much faster than real time (no playback needed),
 * and returns 10 ms RMS bins starting at [startMs]. Returns null when the audio track can't be decoded here.
 */
object AudioScan {
    fun scan(url: String, startMs: Long, durMs: Long, cancelled: () -> Boolean): FloatArray? {
        val ex = MediaExtractor()
        var codec: MediaCodec? = null
        try {
            ex.setDataSource(url, HashMap())
            var track = -1
            var fmt: MediaFormat? = null
            for (i in 0 until ex.trackCount) {
                val f = ex.getTrackFormat(i)
                if ((f.getString(MediaFormat.KEY_MIME) ?: "").startsWith("audio/")) { track = i; fmt = f; break }
            }
            if (track < 0 || fmt == null) return null
            ex.selectTrack(track)
            ex.seekTo(startMs * 1000, MediaExtractor.SEEK_TO_CLOSEST_SYNC)
            val mime = fmt.getString(MediaFormat.KEY_MIME)!!
            codec = MediaCodec.createDecoderByType(mime)
            codec.configure(fmt, null, null, 0)
            codec.start()

            val n = (durMs / 10).toInt() + 1
            val sum = DoubleArray(n)
            val cnt = IntArray(n)
            var rate = if (fmt.containsKey(MediaFormat.KEY_SAMPLE_RATE)) fmt.getInteger(MediaFormat.KEY_SAMPLE_RATE) else 48000
            var ch = if (fmt.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) fmt.getInteger(MediaFormat.KEY_CHANNEL_COUNT) else 2
            val info = MediaCodec.BufferInfo()
            var inDone = false
            var outDone = false
            var got = 0L
            val deadline = System.currentTimeMillis() + 45_000
            val endUs = (startMs + durMs) * 1000

            while (!outDone) {
                if (cancelled() || System.currentTimeMillis() > deadline) return null
                if (!inDone) {
                    val ii = codec.dequeueInputBuffer(5000)
                    if (ii >= 0) {
                        val buf = codec.getInputBuffer(ii)!!
                        val sz = ex.readSampleData(buf, 0)
                        val t = ex.sampleTime
                        if (sz < 0 || (t >= 0 && t > endUs)) {
                            codec.queueInputBuffer(ii, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inDone = true
                        } else {
                            codec.queueInputBuffer(ii, 0, sz, t, 0)
                            ex.advance()
                        }
                    }
                }
                val oi = codec.dequeueOutputBuffer(info, 5000)
                if (oi >= 0) {
                    if (info.size > 0) {
                        val ob = codec.getOutputBuffer(oi)!!
                        ob.position(info.offset)
                        ob.limit(info.offset + info.size)
                        val sb = ob.order(ByteOrder.LITTLE_ENDIAN).asShortBuffer()
                        var frame = 0L
                        while (sb.remaining() >= ch) {
                            var acc = 0
                            for (k in 0 until ch) acc += sb.get().toInt()
                            val m = acc.toDouble() / ch / 32768.0
                            val tMs = (info.presentationTimeUs + frame * 1_000_000L / rate) / 1000 - startMs
                            frame++
                            if (tMs >= 0) {
                                val b = (tMs / 10).toInt()
                                if (b < n) { sum[b] += m * m; cnt[b]++; got++ }
                            }
                        }
                    }
                    codec.releaseOutputBuffer(oi, false)
                    if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) outDone = true
                    if (info.presentationTimeUs > endUs) outDone = true
                } else if (oi == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    val of = codec.outputFormat
                    if (of.containsKey(MediaFormat.KEY_SAMPLE_RATE)) rate = of.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                    if (of.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) ch = of.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                }
            }
            if (got < 48000L * 20) return null
            return FloatArray(n) { if (cnt[it] > 0) sqrt(sum[it] / cnt[it]).toFloat() else 0f }
        } catch (e: Throwable) {
            return null
        } finally {
            try { codec?.stop() } catch (e: Throwable) { }
            try { codec?.release() } catch (e: Throwable) { }
            try { ex.release() } catch (e: Throwable) { }
        }
    }
}
