package com.rakki.boxdlna

import android.content.Context

/** Small settings store (OpenSubtitles API credentials). */
object Cfg {
    private fun p(c: Context) = c.getSharedPreferences("box", Context.MODE_PRIVATE)
    fun apiKey(c: Context): String = p(c).getString("osKey", "") ?: ""
    fun user(c: Context): String = p(c).getString("osUser", "") ?: ""
    fun pass(c: Context): String = p(c).getString("osPass", "") ?: ""
    fun ignoreStop(c: Context): Boolean = p(c).getBoolean("ignoreStop", false)
    fun setIgnoreStop(c: Context, v: Boolean) { p(c).edit().putBoolean("ignoreStop", v).apply() }
    // preferences applied automatically to every new video
    fun prefAudio(c: Context): String = p(c).getString("prefAudio", "") ?: ""
    fun setPrefAudio(c: Context, v: String) { p(c).edit().putString("prefAudio", v).apply() }
    fun prefSub(c: Context): String = p(c).getString("prefSub", "") ?: ""
    fun setPrefSub(c: Context, v: String) { p(c).edit().putString("prefSub", v).apply() }
    fun maxHeight(c: Context): Int = p(c).getInt("maxHeight", 0)
    fun setMaxHeight(c: Context, v: Int) { p(c).edit().putInt("maxHeight", v).apply() }

    // language of the movie's audio for the offline speech recognition used by the subtitle auto sync: eng / fre / off
    fun asrLang(c: Context): String = p(c).getString("asrLang", "eng") ?: "eng"
    fun setAsrLang(c: Context, v: String) { p(c).edit().putString("asrLang", v).apply() }

    fun save(c: Context, key: String, user: String, pass: String) {
        p(c).edit().putString("osKey", key.trim()).putString("osUser", user.trim()).putString("osPass", pass).apply()
    }
}
