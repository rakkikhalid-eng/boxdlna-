package com.rakki.boxdlna

import android.content.Context
import android.net.nsd.NsdManager
import android.net.nsd.NsdServiceInfo
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedInputStream
import java.io.DataInputStream
import java.io.DataOutputStream
import java.net.Socket
import java.security.KeyFactory
import java.security.KeyStore
import java.security.PrivateKey
import java.security.Signature
import java.security.cert.CertificateFactory
import java.security.spec.PKCS8EncodedKeySpec
import java.util.UUID
import java.util.concurrent.CopyOnWriteArrayList
import javax.net.ssl.KeyManagerFactory
import javax.net.ssl.SSLContext
import javax.net.ssl.SSLServerSocket
import javax.net.ssl.SSLSocket

/**
 * Experimental Google Cast (CASTV2) receiver: advertises over mDNS, accepts TLS connections on 8009
 * and plays the media URL a sender LOADs, using the same player as the DLNA side.
 */
class CastServer(
    private val ctx: Context,
    private val udn: String,
    private val volGet: () -> Int,
    private val volSet: (Int) -> Unit
) {
    companion object {
        const val PORT = 8009
        const val NS_AUTH = "urn:x-cast:com.google.cast.tp.deviceauth"
        const val NS_CONN = "urn:x-cast:com.google.cast.tp.connection"
        const val NS_HB = "urn:x-cast:com.google.cast.tp.heartbeat"
        const val NS_RECV = "urn:x-cast:com.google.cast.receiver"
        const val NS_MEDIA = "urn:x-cast:com.google.cast.media"
    }

    private class Conn(val sock: Socket) {
        private val out = DataOutputStream(sock.getOutputStream())
        fun send(src: String, dst: String, ns: String, text: String? = null, bin: ByteArray? = null) {
            val b = CastProto.encode(CastProto.Msg(src, dst, ns, if (text != null) 0 else 1, text, bin))
            synchronized(this) {
                out.writeInt(b.size)
                out.write(b)
                out.flush()
            }
        }
    }

    @Volatile private var alive = false
    private var friendlyName = "Box Chrome"
    private var privKey: PrivateKey? = null
    private var certDer: ByteArray = ByteArray(0)
    private var tlsCertDer: ByteArray = ByteArray(0)
    private var server: SSLServerSocket? = null
    private var httpServer: java.net.ServerSocket? = null
    private val conns = CopyOnWriteArrayList<Conn>()
    private var nsd: NsdManager? = null
    private var reg: NsdManager.RegistrationListener? = null
    private var disc: NsdManager.DiscoveryListener? = null

    @Volatile private var sessionId: String? = null
    @Volatile private var transportId = ""
    @Volatile private var appId = "CC1AD845"
    @Volatile private var contentType = "video/mp4"

    fun start(friendly: String) {
        if (alive) return
        alive = true
        friendlyName = friendly
        val key = KeyFactory.getInstance("RSA").generatePrivate(
            PKCS8EncodedKeySpec(ctx.assets.open("cast_key.der").use { it.readBytes() })
        )
        val cf = CertificateFactory.getInstance("X.509")
        val cert = ctx.assets.open("cast_cert.der").use { cf.generateCertificate(it) }
        privKey = key
        certDer = cert.encoded
        val prof = ctx.getSharedPreferences("box", Context.MODE_PRIVATE).getInt("tlsProfile", 0)
        val useEc = prof % 2 == 1
        val only12 = prof >= 2
        val tlsKey: PrivateKey
        val tlsCert: java.security.cert.Certificate
        if (useEc) {
            tlsKey = KeyFactory.getInstance("EC").generatePrivate(
                PKCS8EncodedKeySpec(ctx.assets.open("cast_ec_key.der").use { it.readBytes() })
            )
            tlsCert = ctx.assets.open("cast_ec_cert.der").use { cf.generateCertificate(it) }
        } else {
            tlsKey = key
            tlsCert = cert
        }
        tlsCertDer = tlsCert.encoded
        val ks = KeyStore.getInstance(KeyStore.getDefaultType())
        ks.load(null, null)
        val pw = "boxchrome".toCharArray()
        ks.setKeyEntry("k", tlsKey, pw, arrayOf(tlsCert))
        val kmf = KeyManagerFactory.getInstance(KeyManagerFactory.getDefaultAlgorithm())
        kmf.init(ks, pw)
        val sc = SSLContext.getInstance("TLS")
        sc.init(kmf.keyManagers, null, null)
        val ss = sc.serverSocketFactory.createServerSocket() as SSLServerSocket
        ss.reuseAddress = true
        ss.bind(java.net.InetSocketAddress(PORT))
        if (only12) { try { ss.enabledProtocols = arrayOf("TLSv1.2") } catch (e: Exception) { } }
        server = ss
        CastDiag.tls = "TLS: يستمع على 8009 ✓ (ملف " + prof + " — " + (if (useEc) "EC" else "RSA") + " — " + ss.enabledProtocols.joinToString("/") + ")"

        spawn {
            while (alive) {
                val s = try { ss.accept() } catch (e: Exception) { break }
                CastDiag.conns++
                spawn { serve(s) }
            }
        }

        spawn {
            while (alive) {
                try { Thread.sleep(2000) } catch (e: Exception) { }
                if (sessionId != null && Renderer.state == "PLAYING") broadcastMedia(0)
            }
        }

        spawn { httpLoop() }

        register(friendly)
    }

    private fun spawn(f: () -> Unit) {
        Thread {
            try {
                f()
            } catch (t: Throwable) {
                try {
                    java.io.File(ctx.filesDir, "crash.txt").writeText("cast thread\n" + android.util.Log.getStackTraceString(t))
                    ctx.getSharedPreferences("box", Context.MODE_PRIVATE).edit().putBoolean("castOff", true).commit()
                } catch (x: Throwable) { }
                try { stop() } catch (x: Throwable) { }
            }
        }.start()
    }

    fun stop() {
        alive = false
        try { server?.close() } catch (e: Exception) { }
        try { httpServer?.close() } catch (e: Exception) { }
        for (c in conns) try { c.sock.close() } catch (e: Exception) { }
        try { reg?.let { nsd?.unregisterService(it) } } catch (e: Exception) { }
        try { disc?.let { nsd?.stopServiceDiscovery(it) } } catch (e: Exception) { }
    }

    fun onStateChanged() {
        if (alive && sessionId != null) broadcastMedia(0)
    }

    private fun register(friendly: String) {
        val id = udn.replace("-", "")
        val si = NsdServiceInfo()
        si.serviceName = "BoxChrome-" + id.take(12)
        si.serviceType = "_googlecast._tcp"
        si.port = PORT
        fun attr(k: String, v: String) { try { si.setAttribute(k, v) } catch (e: Exception) { } }
        attr("id", id); attr("cd", id); attr("rm", ""); attr("ve", "05"); attr("md", "Chromecast")
        attr("ic", "/setup/icon.png"); attr("fn", friendly); attr("ca", "4101"); attr("st", "0")
        attr("bs", id.take(12).uppercase()); attr("nf", "1"); attr("rs", "")
        val l = object : NsdManager.RegistrationListener {
            override fun onRegistrationFailed(s: NsdServiceInfo?, code: Int) { CastDiag.mdns = "mDNS: فشل التسجيل (رمز " + code + ")" }
            override fun onUnregistrationFailed(s: NsdServiceInfo?, code: Int) { }
            override fun onServiceRegistered(s: NsdServiceInfo?) { CastDiag.mdns = "mDNS: مسجَّل باسم " + (s?.serviceName ?: "؟") + " ✓" }
            override fun onServiceUnregistered(s: NsdServiceInfo?) { CastDiag.mdns = "mDNS: أُلغي التسجيل" }
        }
        val m = ctx.getSystemService(Context.NSD_SERVICE) as NsdManager
        nsd = m
        reg = l
        CastDiag.mdns = "mDNS: جارٍ التسجيل…"
        m.registerService(si, NsdManager.PROTOCOL_DNS_SD, l)

        val d = object : NsdManager.DiscoveryListener {
            override fun onDiscoveryStarted(t: String?) { }
            override fun onDiscoveryStopped(t: String?) { }
            override fun onServiceFound(s: NsdServiceInfo?) { s?.serviceName?.let { CastDiag.found.add(it) } }
            override fun onServiceLost(s: NsdServiceInfo?) { s?.serviceName?.let { CastDiag.found.remove(it) } }
            override fun onStartDiscoveryFailed(t: String?, code: Int) { }
            override fun onStopDiscoveryFailed(t: String?, code: Int) { }
        }
        disc = d
        try { m.discoverServices("_googlecast._tcp", NsdManager.PROTOCOL_DNS_SD, d) } catch (e: Exception) { }
    }

    // ------------------------------------------------------------------ connection loop

    private fun serve(sock: Socket) {
        var c: Conn? = null
        val t0 = System.currentTimeMillis()
        val who = sock.remoteSocketAddress?.toString() ?: "?"
        try {
            val ssl = sock as? SSLSocket
            if (ssl != null) {
                ssl.startHandshake()
                CastDiag.log("TLS ✓ " + who + " " + ssl.session.protocol + " " + ssl.session.cipherSuite)
            }
            c = Conn(sock)
            conns.add(c)
            sock.soTimeout = 60000
            val inp = DataInputStream(BufferedInputStream(sock.getInputStream()))
            while (alive) {
                val len = inp.readInt()
                if (len <= 0 || len > 2_000_000) break
                val buf = ByteArray(len)
                inp.readFully(buf)
                val m = CastProto.decode(buf) ?: continue
                try { handle(c, m) } catch (e: Exception) { }
            }
        } catch (e: Exception) {
            CastDiag.log("أُغلق بعد " + (System.currentTimeMillis() - t0) + "ms من " + who + ": " + chain(e))
        } finally {
            if (c != null) conns.remove(c)
            try { sock.close() } catch (e: Exception) { }
        }
    }

    private fun authMode(): Int = ctx.getSharedPreferences("box", Context.MODE_PRIVATE).getInt("authMode", 1)

    private fun authError(): ByteArray = byteArrayOf(0x1A, 0x02, 0x08, 0x00)

    private fun authReply(ch: CastProto.Challenge): ByteArray {
        val key = privKey ?: return authError()
        val sg = Signature.getInstance(if (ch.hashAlg == 1) "SHA256withRSA" else "SHA1withRSA")
        sg.initSign(key)
        sg.update(ch.nonce)
        sg.update(tlsCertDer)
        return CastProto.authResponse(sg.sign(), certDer, ch.nonce, ch.sigAlg, ch.hashAlg)
    }

    private fun auth(c: Conn, m: CastProto.Msg) {
        val bin = m.bin
        val ch = if (bin != null) CastProto.parseChallenge(bin) else null
        val mode = authMode()
        CastDiag.log("تحدّي التحقق: sig=" + (ch?.sigAlg ?: -1) + " hash=" + (ch?.hashAlg ?: -1) + " nonce=" + (ch?.nonce?.size ?: -1) + " ← وضع " + mode)
        when (mode) {
            0 -> { }
            1 -> c.send(m.dst, m.src, NS_AUTH, bin = if (ch != null) authReply(ch) else authError())
            else -> c.send(m.dst, m.src, NS_AUTH, bin = authError())
        }
    }

    // ------------------------------------------------------------------ HTTP 8008 (device info like a real Chromecast)

    private fun eurekaJson(ip: String): String =
        JSONObject().put("name", friendlyName).put("version", 12).put("build_version", "260000")
            .put("cast_build_revision", "1.56.500000").put("setup_state", 60)
            .put("ssdp_udn", udn).put("ip_address", ip).put("mac_address", "00:00:00:00:00:00")
            .put("locale", "en-US").put("time_format", 1).put("uptime", 1000.0)
            .put("wpa_configured", true).put("connected", true).put("has_update", false)
            .put("release_track", "stable-channel").put("ethernet_connected", false).toString()

    private fun dialXml(): String =
        "<?xml version=\"1.0\"?><root xmlns=\"urn:schemas-upnp-org:device-1-0\"><specVersion><major>1</major><minor>0</minor></specVersion>" +
            "<device><deviceType>urn:dial-multiscreen-org:device:dial:1</deviceType><friendlyName>" + friendlyName +
            "</friendlyName><manufacturer>Google Inc.</manufacturer><modelName>Eureka Dongle</modelName><UDN>uuid:" + udn + "</UDN></device></root>"

    private fun httpLoop() {
        val hs = java.net.ServerSocket()
        hs.reuseAddress = true
        hs.bind(java.net.InetSocketAddress(8008))
        httpServer = hs
        while (alive) {
            val s = try { hs.accept() } catch (e: Exception) { break }
            spawn { httpHandle(s) }
        }
    }

    private fun httpHandle(s: Socket) {
        s.use {
            s.soTimeout = 5000
            val r = java.io.BufferedReader(java.io.InputStreamReader(s.getInputStream()))
            val first = r.readLine() ?: return
            while (true) {
                val l = r.readLine() ?: break
                if (l.isEmpty()) break
            }
            val path = first.split(" ").getOrElse(1) { "/" }.substringBefore('?')
            CastDiag.log("HTTP 8008: " + path)
            val ip = NetUtil.local()?.first ?: "127.0.0.1"
            val type: String
            val body: String
            var extra = ""
            when (path) {
                "/setup/eureka_info" -> { type = "application/json"; body = eurekaJson(ip) }
                "/ssdp/device-desc.xml" -> { type = "text/xml"; body = dialXml(); extra = "Application-URL: http://" + ip + ":8008/apps/\r\n" }
                else -> { type = "text/plain"; body = "" }
            }
            val b = body.toByteArray()
            val out = s.getOutputStream()
            out.write(
                ("HTTP/1.1 " + (if (body.isEmpty()) "404 Not Found" else "200 OK") + "\r\nContent-Type: " + type +
                    "\r\nContent-Length: " + b.size + "\r\nAccess-Control-Allow-Origin: *\r\nConnection: close\r\n" + extra + "\r\n").toByteArray()
            )
            out.write(b)
            out.flush()
        }
    }

    private fun chain(e: Throwable): String {
        val sb = StringBuilder()
        var t: Throwable? = e
        var n = 0
        while (t != null && n < 4) {
            if (sb.isNotEmpty()) sb.append(" | ")
            sb.append(t.javaClass.simpleName).append(": ").append(t.message ?: "")
            t = t.cause
            n++
        }
        return sb.toString().take(300)
    }

    private fun json(m: CastProto.Msg): JSONObject = try { JSONObject(m.text ?: "{}") } catch (e: Exception) { JSONObject() }

    private fun handle(c: Conn, m: CastProto.Msg) {
        val tail = m.ns.substringAfterLast('.')
        val typ = if (m.type == 0) json(m).optString("type") else "binary"
        CastDiag.last = tail + " " + typ
        if (tail != "heartbeat") CastDiag.log("وصلت: " + tail + " " + typ)
        when (m.ns) {
            NS_AUTH -> auth(c, m)
            NS_HB -> if (json(m).optString("type") == "PING") c.send(m.dst, m.src, NS_HB, "{\"type\":\"PONG\"}")
            NS_RECV -> receiver(c, m)
            NS_MEDIA -> media(c, m)
            else -> { }
        }
    }

    // ------------------------------------------------------------------ receiver namespace

    private fun receiverStatus(rid: Int): String {
        val apps = JSONArray()
        val sid = sessionId
        if (sid != null) {
            apps.put(
                JSONObject().put("appId", appId).put("displayName", "Default Media Receiver")
                    .put("namespaces", JSONArray().put(JSONObject().put("name", NS_MEDIA)))
                    .put("sessionId", sid).put("statusText", "Ready To Cast").put("transportId", transportId)
            )
        }
        val st = JSONObject().put("applications", apps).put("isActiveInput", true)
            .put("volume", JSONObject().put("level", volGet() / 100.0).put("muted", false))
        return JSONObject().put("requestId", rid).put("type", "RECEIVER_STATUS").put("status", st).toString()
    }

    private fun broadcastReceiver(rid: Int) {
        val s = receiverStatus(rid)
        for (c in conns) try { c.send("receiver-0", "*", NS_RECV, s) } catch (e: Exception) { }
    }

    private fun receiver(c: Conn, m: CastProto.Msg) {
        val j = json(m)
        val rid = j.optInt("requestId", 0)
        when (j.optString("type")) {
            "GET_STATUS" -> c.send(m.dst, m.src, NS_RECV, receiverStatus(rid))
            "GET_APP_AVAILABILITY" -> {
                val ids = j.optJSONArray("appId")
                val av = JSONObject()
                if (ids != null) for (i in 0 until ids.length()) av.put(ids.getString(i), "APP_AVAILABLE")
                c.send(
                    m.dst, m.src, NS_RECV,
                    JSONObject().put("requestId", rid).put("responseType", "GET_APP_AVAILABILITY")
                        .put("availability", av).toString()
                )
            }
            "LAUNCH" -> {
                appId = j.optString("appId", "CC1AD845")
                sessionId = UUID.randomUUID().toString()
                transportId = "web-" + (System.nanoTime() % 100000)
                broadcastReceiver(rid)
            }
            "STOP" -> {
                sessionId = null
                Renderer.stop()
                broadcastReceiver(rid)
            }
            "SET_VOLUME" -> {
                val v = j.optJSONObject("volume")
                if (v != null && v.has("level")) volSet((v.optDouble("level", 1.0) * 100).toInt())
                broadcastReceiver(rid)
            }
        }
    }

    // ------------------------------------------------------------------ media namespace

    private fun mediaStatus(rid: Int): String {
        val ps = when (Renderer.state) {
            "PLAYING" -> "PLAYING"
            "PAUSED_PLAYBACK" -> "PAUSED"
            "TRANSITIONING" -> "BUFFERING"
            else -> "IDLE"
        }
        val arr = JSONArray()
        if (Renderer.uri.isNotEmpty() && sessionId != null) {
            val media = JSONObject().put("contentId", Renderer.uri).put("streamType", "BUFFERED").put("contentType", contentType)
            if (Renderer.durMs > 0) media.put("duration", Renderer.durMs / 1000.0)
            val o = JSONObject().put("mediaSessionId", 1).put("playerState", ps)
                .put("currentTime", Renderer.posMs / 1000.0).put("supportedMediaCommands", 15)
                .put("playbackRate", 1).put("currentItemId", 1).put("media", media)
                .put("volume", JSONObject().put("level", volGet() / 100.0).put("muted", false))
            if (ps == "IDLE") o.put("idleReason", "FINISHED")
            arr.put(o)
        }
        return JSONObject().put("requestId", rid).put("type", "MEDIA_STATUS").put("status", arr).toString()
    }

    private fun broadcastMedia(rid: Int) {
        val s = mediaStatus(rid)
        for (c in conns) try { c.send(transportId.ifEmpty { "receiver-0" }, "*", NS_MEDIA, s) } catch (e: Exception) { }
    }

    private fun media(c: Conn, m: CastProto.Msg) {
        val j = json(m)
        val rid = j.optInt("requestId", 0)
        when (j.optString("type")) {
            "GET_STATUS" -> { c.send(m.dst, m.src, NS_MEDIA, mediaStatus(rid)); return }
            "LOAD" -> {
                val media = j.optJSONObject("media") ?: return
                val cid = media.optString("contentId")
                val url = if (cid.startsWith("http")) cid else media.optString("contentUrl").ifEmpty { cid }
                if (url.isEmpty()) return
                contentType = media.optString("contentType", "video/mp4")
                var sub: String? = null
                val tracks = media.optJSONArray("tracks")
                if (tracks != null) {
                    for (i in 0 until tracks.length()) {
                        val t = tracks.optJSONObject(i) ?: continue
                        val u = t.optString("trackContentId")
                        if (t.optString("type") == "TEXT" && u.isNotEmpty()) { sub = u; break }
                    }
                }
                Renderer.setUri(url, "")
                if (sub != null) Renderer.subUrl = sub
                Renderer.startMs = (j.optDouble("currentTime", 0.0) * 1000).toLong()
                if (j.optBoolean("autoplay", true)) Renderer.play(ctx)
            }
            "PLAY" -> Renderer.play(ctx)
            "PAUSE" -> Renderer.pause()
            "SEEK" -> Renderer.seek((j.optDouble("currentTime", 0.0) * 1000).toLong())
            "STOP" -> Renderer.stop()
        }
        broadcastMedia(rid)
    }
}
