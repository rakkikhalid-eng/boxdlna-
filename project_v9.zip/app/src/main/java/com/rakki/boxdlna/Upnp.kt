package com.rakki.boxdlna

object Upnp {
    const val AVT = "urn:schemas-upnp-org:service:AVTransport:1"
    const val RC = "urn:schemas-upnp-org:service:RenderingControl:1"
    const val CM = "urn:schemas-upnp-org:service:ConnectionManager:1"

    private class V(
        val n: String, val t: String, val ev: Boolean = false,
        val allowed: List<String> = emptyList(), val range: Boolean = false
    )

    private class A(
        val n: String,
        val ins: List<Pair<String, String>> = emptyList(),
        val outs: List<Pair<String, String>> = emptyList()
    )

    private val IID = "InstanceID" to "A_ARG_TYPE_InstanceID"
    private val CH = "Channel" to "A_ARG_TYPE_Channel"

    private fun build(vs: List<V>, acts: List<A>): String {
        val sb = StringBuilder("<?xml version=\"1.0\"?><scpd xmlns=\"urn:schemas-upnp-org:service-1-0\"><specVersion><major>1</major><minor>0</minor></specVersion><actionList>")
        for (a in acts) {
            sb.append("<action><name>${a.n}</name><argumentList>")
            for ((n, r) in a.ins) sb.append("<argument><name>$n</name><direction>in</direction><relatedStateVariable>$r</relatedStateVariable></argument>")
            for ((n, r) in a.outs) sb.append("<argument><name>$n</name><direction>out</direction><relatedStateVariable>$r</relatedStateVariable></argument>")
            sb.append("</argumentList></action>")
        }
        sb.append("</actionList><serviceStateTable>")
        for (v in vs) {
            sb.append("<stateVariable sendEvents=\"${if (v.ev) "yes" else "no"}\"><name>${v.n}</name><dataType>${v.t}</dataType>")
            if (v.allowed.isNotEmpty()) {
                sb.append("<allowedValueList>")
                v.allowed.forEach { sb.append("<allowedValue>$it</allowedValue>") }
                sb.append("</allowedValueList>")
            }
            if (v.range) sb.append("<allowedValueRange><minimum>0</minimum><maximum>100</maximum><step>1</step></allowedValueRange>")
            sb.append("</stateVariable>")
        }
        sb.append("</serviceStateTable></scpd>")
        return sb.toString()
    }

    val avtScpd: String by lazy {
        build(
            listOf(
                V("TransportState", "string", allowed = listOf("STOPPED", "PLAYING", "PAUSED_PLAYBACK", "TRANSITIONING", "NO_MEDIA_PRESENT")),
                V("TransportStatus", "string", allowed = listOf("OK", "ERROR_OCCURRED")),
                V("PlaybackStorageMedium", "string"), V("PossiblePlaybackStorageMedia", "string"),
                V("RecordStorageMedium", "string"), V("PossibleRecordStorageMedia", "string"),
                V("CurrentPlayMode", "string", allowed = listOf("NORMAL")),
                V("TransportPlaySpeed", "string", allowed = listOf("1")),
                V("RecordMediumWriteStatus", "string"), V("CurrentRecordQualityMode", "string"),
                V("PossibleRecordQualityModes", "string"),
                V("NumberOfTracks", "ui4"), V("CurrentTrack", "ui4"),
                V("CurrentTrackDuration", "string"), V("CurrentMediaDuration", "string"),
                V("CurrentTrackMetaData", "string"), V("CurrentTrackURI", "string"),
                V("AVTransportURI", "string"), V("AVTransportURIMetaData", "string"),
                V("NextAVTransportURI", "string"), V("NextAVTransportURIMetaData", "string"),
                V("RelativeTimePosition", "string"), V("AbsoluteTimePosition", "string"),
                V("RelativeCounterPosition", "i4"), V("AbsoluteCounterPosition", "ui4"),
                V("CurrentTransportActions", "string"),
                V("LastChange", "string", ev = true),
                V("A_ARG_TYPE_SeekMode", "string", allowed = listOf("REL_TIME", "ABS_TIME", "TRACK_NR")),
                V("A_ARG_TYPE_SeekTarget", "string"), V("A_ARG_TYPE_InstanceID", "ui4")
            ),
            listOf(
                A("SetAVTransportURI", listOf(IID, "CurrentURI" to "AVTransportURI", "CurrentURIMetaData" to "AVTransportURIMetaData")),
                A("SetNextAVTransportURI", listOf(IID, "NextURI" to "NextAVTransportURI", "NextURIMetaData" to "NextAVTransportURIMetaData")),
                A("GetMediaInfo", listOf(IID), listOf(
                    "NrTracks" to "NumberOfTracks", "MediaDuration" to "CurrentMediaDuration",
                    "CurrentURI" to "AVTransportURI", "CurrentURIMetaData" to "AVTransportURIMetaData",
                    "NextURI" to "NextAVTransportURI", "NextURIMetaData" to "NextAVTransportURIMetaData",
                    "PlayMedium" to "PlaybackStorageMedium", "RecordMedium" to "RecordStorageMedium",
                    "WriteStatus" to "RecordMediumWriteStatus")),
                A("GetTransportInfo", listOf(IID), listOf(
                    "CurrentTransportState" to "TransportState", "CurrentTransportStatus" to "TransportStatus",
                    "CurrentSpeed" to "TransportPlaySpeed")),
                A("GetPositionInfo", listOf(IID), listOf(
                    "Track" to "CurrentTrack", "TrackDuration" to "CurrentTrackDuration",
                    "TrackMetaData" to "CurrentTrackMetaData", "TrackURI" to "CurrentTrackURI",
                    "RelTime" to "RelativeTimePosition", "AbsTime" to "AbsoluteTimePosition",
                    "RelCount" to "RelativeCounterPosition", "AbsCount" to "AbsoluteCounterPosition")),
                A("GetDeviceCapabilities", listOf(IID), listOf(
                    "PlayMedia" to "PossiblePlaybackStorageMedia", "RecMedia" to "PossibleRecordStorageMedia",
                    "RecQualityModes" to "PossibleRecordQualityModes")),
                A("GetTransportSettings", listOf(IID), listOf(
                    "PlayMode" to "CurrentPlayMode", "RecQualityMode" to "CurrentRecordQualityMode")),
                A("Stop", listOf(IID)),
                A("Play", listOf(IID, "Speed" to "TransportPlaySpeed")),
                A("Pause", listOf(IID)),
                A("Seek", listOf(IID, "Unit" to "A_ARG_TYPE_SeekMode", "Target" to "A_ARG_TYPE_SeekTarget")),
                A("Next", listOf(IID)),
                A("Previous", listOf(IID)),
                A("SetPlayMode", listOf(IID, "NewPlayMode" to "CurrentPlayMode")),
                A("GetCurrentTransportActions", listOf(IID), listOf("Actions" to "CurrentTransportActions"))
            )
        )
    }

    val rcScpd: String by lazy {
        build(
            listOf(
                V("LastChange", "string", ev = true),
                V("PresetNameList", "string"),
                V("Mute", "boolean"),
                V("Volume", "ui2", range = true),
                V("A_ARG_TYPE_InstanceID", "ui4"),
                V("A_ARG_TYPE_PresetName", "string", allowed = listOf("FactoryDefaults")),
                V("A_ARG_TYPE_Channel", "string", allowed = listOf("Master"))
            ),
            listOf(
                A("ListPresets", listOf(IID), listOf("CurrentPresetNameList" to "PresetNameList")),
                A("SelectPreset", listOf(IID, "PresetName" to "A_ARG_TYPE_PresetName")),
                A("GetMute", listOf(IID, CH), listOf("CurrentMute" to "Mute")),
                A("SetMute", listOf(IID, CH, "DesiredMute" to "Mute")),
                A("GetVolume", listOf(IID, CH), listOf("CurrentVolume" to "Volume")),
                A("SetVolume", listOf(IID, CH, "DesiredVolume" to "Volume"))
            )
        )
    }

    val cmScpd: String by lazy {
        build(
            listOf(
                V("SourceProtocolInfo", "string"), V("SinkProtocolInfo", "string"),
                V("CurrentConnectionIDs", "string"),
                V("A_ARG_TYPE_ConnectionStatus", "string", allowed = listOf("OK", "ContentFormatMismatch", "InsufficientBandwidth", "UnreliableChannel", "Unknown")),
                V("A_ARG_TYPE_ConnectionManager", "string"),
                V("A_ARG_TYPE_Direction", "string", allowed = listOf("Input", "Output")),
                V("A_ARG_TYPE_ProtocolInfo", "string"),
                V("A_ARG_TYPE_ConnectionID", "i4"), V("A_ARG_TYPE_AVTransportID", "i4"),
                V("A_ARG_TYPE_RcsID", "i4")
            ),
            listOf(
                A("GetProtocolInfo", outs = listOf("Source" to "SourceProtocolInfo", "Sink" to "SinkProtocolInfo")),
                A("GetCurrentConnectionIDs", outs = listOf("ConnectionIDs" to "CurrentConnectionIDs")),
                A("GetCurrentConnectionInfo", listOf("ConnectionID" to "A_ARG_TYPE_ConnectionID"), listOf(
                    "RcsID" to "A_ARG_TYPE_RcsID", "AVTransportID" to "A_ARG_TYPE_AVTransportID",
                    "ProtocolInfo" to "A_ARG_TYPE_ProtocolInfo", "PeerConnectionManager" to "A_ARG_TYPE_ConnectionManager",
                    "PeerConnectionID" to "A_ARG_TYPE_ConnectionID", "Direction" to "A_ARG_TYPE_Direction",
                    "Status" to "A_ARG_TYPE_ConnectionStatus"))
            )
        )
    }
}
