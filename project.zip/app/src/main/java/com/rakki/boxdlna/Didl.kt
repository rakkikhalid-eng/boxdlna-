package com.rakki.boxdlna

/** Reads every video source and subtitle the sender announced in its DIDL-Lite metadata (not only the first). */
object Didl {
    class Src(val url: String, val label: String, val height: Int, val bitrate: Int)
    class ExtraSub(val url: String, var label: String, var lang: String = "", var file: String = "")

    private val RES = Regex("<res\\s+([^>]*)>([^<]+)</res>", RegexOption.DOT_MATCHES_ALL)
    private val CAP = Regex("<(?:sec:CaptionInfoEx|sec:CaptionInfo|pv:subtitleFileUri)([^>]*)>([^<]+)</", RegexOption.DOT_MATCHES_ALL)

    private fun attr(a: String, name: String): String =
        Regex("\\b(?:\\w+:)?$name=\"([^\"]*)\"").find(a)?.groupValues?.get(1)?.let { unesc(it) } ?: ""

    private fun isSub(u: String, mime: String): Boolean {
        val l = u.substringBefore('?').lowercase()
        return mime.startsWith("text/") || mime.contains("subrip") || mime.contains("srt") || mime.contains("vtt") ||
            l.endsWith(".srt") || l.endsWith(".vtt") || l.endsWith(".ass") || l.endsWith(".ssa")
    }

    private fun nameOf(u: String): String = u.substringBefore('?').substringAfterLast('/')

    fun parse(meta: String): Pair<List<Src>, List<ExtraSub>> {
        val srcs = ArrayList<Src>()
        val subs = ArrayList<ExtraSub>()
        val seen = HashSet<String>()
        for (m in RES.findAll(meta)) {
            val attrs = m.groupValues[1]
            val url = unesc(m.groupValues[2]).trim()
            if (!url.startsWith("http")) continue
            val mime = Regex("protocolInfo=\"[^:\"]*:[^:\"]*:([^:\"]+)").find(attrs)?.groupValues?.get(1)?.lowercase() ?: ""
            if (mime.startsWith("image/")) continue
            if (isSub(url, mime)) {
                if (seen.add(url)) subs.add(ExtraSub(url, attr(attrs, "label").ifEmpty { nameOf(url) }, attr(attrs, "lang")))
            } else {
                var h = Regex("resolution=\"\\d+x(\\d+)\"").find(attrs)?.groupValues?.get(1)?.toIntOrNull() ?: 0
                if (h == 0) h = attr(attrs, "height").toIntOrNull() ?: 0
                val br = attr(attrs, "bitrate").toIntOrNull() ?: 0
                var lab = attr(attrs, "label")
                if (h == 0) h = Regex("(\\d{3,4})p").find("$lab $url")?.groupValues?.get(1)?.toIntOrNull() ?: 0
                if (lab.isEmpty()) lab = if (h > 0) "${h}p" else if (br > 0) "${br / 1000} kbps" else "Source " + (srcs.size + 1)
                srcs.add(Src(url, lab, h, br))
            }
        }
        for (m in CAP.findAll(meta)) {
            val url = unesc(m.groupValues[2]).trim()
            if (url.startsWith("http") && seen.add(url)) {
                subs.add(ExtraSub(url, attr(m.groupValues[1], "label").ifEmpty { nameOf(url) }, attr(m.groupValues[1], "lang")))
            }
        }
        return srcs to subs
    }
}
