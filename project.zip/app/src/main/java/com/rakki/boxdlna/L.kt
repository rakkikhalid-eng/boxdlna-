package com.rakki.boxdlna

import android.content.Context

/** Tiny i18n helper: French (default), Arabic, English. */
object L {
    val codes = listOf("fr", "ar", "en")
    val nativeNames = listOf("Français", "العربية", "English")
    var idx = 0
    val rtl: Boolean get() = idx == 1

    private fun prefs(c: Context) = c.getSharedPreferences("box", Context.MODE_PRIVATE)

    fun init(c: Context) {
        idx = codes.indexOf(prefs(c).getString("lang", "fr")).coerceAtLeast(0)
    }

    fun set(c: Context, i: Int) {
        idx = ((i % 3) + 3) % 3
        prefs(c).edit().putString("lang", codes[idx]).apply()
    }

    fun t(k: String): String = T[k]?.getOrNull(idx) ?: k

    private fun e(fr: String, ar: String, en: String) = listOf(fr, ar, en)

    private val T: Map<String, List<String>> = mapOf(
        // ---- player menu
        "options" to e("Options", "الخيارات", "Options"),
        "settings" to e("Paramètres", "الإعدادات", "Settings"),
        "subtitles" to e("Sous-titres", "الترجمة", "Subtitles"),
        "lock" to e("Verrouiller l'écran", "قفل الشاشة", "Lock screen"),
        "unlock" to e("Déverrouiller l'écran", "فتح قفل الشاشة", "Unlock screen"),
        "stop" to e("Arrêter la lecture", "إيقاف التشغيل", "Stop playback"),
        "aspect" to e("Format de l'image", "حجم الصورة", "Picture size"),
        "asp0" to e("Ajusté", "ملائمة", "Fit"),
        "asp1" to e("Plein écran (rogné)", "ملء الشاشة (قص)", "Fill (crop)"),
        "asp2" to e("Étiré", "تمديد", "Stretch"),
        "asp3" to e("16:9", "16:9", "16:9"),
        "asp4" to e("4:3", "4:3", "4:3"),
        "speed" to e("Vitesse de lecture", "سرعة التشغيل", "Playback speed"),
        "language" to e("Langue de l'interface", "لغة الواجهة", "Interface language"),
        "quit" to e("Quitter l'application", "إيقاف التطبيق نهائيًا", "Quit application"),
        "search_box" to e("Chercher dans la box", "البحث داخل البوكس", "Search on this box"),
        "search_online" to e("Chercher en ligne", "البحث على الإنترنت", "Search online"),
        "search_lang" to e("Langue de recherche", "لغة البحث", "Search language"),
        "lang_ara" to e("Arabe", "العربية", "Arabic"),
        "lang_fre" to e("Français", "الفرنسية", "French"),
        "lang_eng" to e("Anglais", "الإنجليزية", "English"),
        "subs_show" to e("Afficher les sous-titres", "عرض الترجمة", "Show subtitles"),
        "on" to e("Oui", "نعم", "On"),
        "off" to e("Non", "لا", "Off"),
        "delay" to e("Décalage (OK = zéro)", "تأخير الترجمة (OK = تصفير)", "Delay (OK = reset)"),
        "quicksync" to e("Synchro rapide (OK à une phrase)", "مزامنة سريعة (OK عند جملة)", "Quick sync (OK on a line)"),
        "autosync" to e("Synchro auto (analyse audio)", "مزامنة تلقائية (تحليل الصوت)", "Auto sync (audio analysis)"),
        "appearance" to e("Apparence", "شكل الترجمة", "Appearance"),
        "font_size" to e("Taille du texte", "حجم الخط", "Text size"),
        "font_color" to e("Couleur du texte", "لون الخط", "Text color"),
        "bg_color" to e("Couleur du fond", "لون الخلفية", "Background color"),
        "bg_opacity" to e("Opacité du fond", "كثافة الخلفية", "Background opacity"),
        "height" to e("Hauteur", "ارتفاع الترجمة", "Height"),
        "outline" to e("Contour", "حواف الحروف", "Outline"),
        "reset_style" to e("Réinitialiser l'apparence", "إعادة ضبط الشكل", "Reset appearance"),
        "transparent" to e("Transparent", "شفافة", "Transparent"),
        "custom" to e("Perso", "مخصص", "Custom"),
        "c_white" to e("Blanc", "أبيض", "White"),
        "c_yellow" to e("Jaune", "أصفر", "Yellow"),
        "c_cyan" to e("Cyan", "سماوي", "Cyan"),
        "c_green" to e("Vert", "أخضر", "Green"),
        "c_orange" to e("Orange", "برتقالي", "Orange"),
        "c_lgray" to e("Gris clair", "رمادي فاتح", "Light gray"),
        "c_black" to e("Noir", "أسود", "Black"),
        "c_dgray" to e("Gris foncé", "رمادي غامق", "Dark gray"),
        "c_blue" to e("Bleu", "أزرق", "Blue"),
        "c_dred" to e("Rouge foncé", "أحمر داكن", "Dark red"),
        "p_fit" to e("Ajuster", "ملاءمة", "Fit"),
        "p_subs" to e("Sous-titres", "الترجمة", "Subtitles"),
        "p_audio" to e("Audio", "الصوت", "Audio"),
        "p_options" to e("Options", "الخيارات", "Options"),
        "sync_already" to e("Déjà synchronisé, rien à changer", "الترجمة متزامنة أصلًا، لا حاجة للتغيير", "Already in sync, nothing changed"),
        "undo_sync" to e("Annuler la dernière synchro", "التراجع عن آخر مزامنة", "Undo last sync"),
        "undone" to e("Synchro annulée", "تم التراجع", "Sync undone"),
        "ignore_stop" to e("Ignorer « Stop » du téléphone", "تجاهل أمر الإيقاف من الهاتف", "Ignore phone's Stop"),
        "hash_hit" to e("Même fichier", "نفس الملف", "Same file"),
        "log_card" to e("Journal des commandes reçues", "سجل الأوامر الواردة من المرسل", "Commands received from sender"),
        "log_empty" to e("(aucune commande)", "(لا توجد أوامر بعد)", "(no commands yet)"),
        "sub_off" to e("Désactivés", "إيقاف الترجمة", "Off"),
        "sub_sender" to e("Envoyés par l'appli", "من التطبيق المرسل", "From sender app"),
        "sub_settings" to e("Réglages des sous-titres", "إعدادات الترجمة", "Subtitle settings"),
        "edit_title" to e("Modifier le titre de recherche", "تعديل اسم البحث", "Edit search title"),
        "cancel" to e("Annuler", "إلغاء", "Cancel"),
        "source_lost" to e("Source perdue (l'appli émettrice est fermée)", "انقطع المصدر (أُغلق التطبيق المرسل)", "Source lost (sender app closed)"),
        "sec" to e("s", "ث", "s"),
        // ---- search / sync messages
        "season" to e("Saison", "الموسم", "Season"),
        "episode" to e("Épisode", "الحلقة", "Episode"),
        "year" to e("Année", "السنة", "Year"),
        "do_search" to e("Lancer la recherche", "ابدأ البحث", "Run search"),
        "searching" to e("Recherche…", "جارٍ البحث…", "Searching…"),
        "no_results" to e("Aucun résultat", "لا توجد نتائج", "No results"),
        "no_perm" to e("Accès aux fichiers refusé (voir l'écran d'accueil)", "لا يوجد إذن الملفات (راجع الشاشة الرئيسية)", "No file access (see home screen)"),
        "net_error" to e("Erreur réseau", "خطأ في الشبكة", "Network error"),
        "downloading" to e("Téléchargement…", "جارٍ التنزيل…", "Downloading…"),
        "applied" to e("Sous-titres appliqués", "تم تطبيق الترجمة", "Subtitles applied"),
        "sub_error" to e("Fichier illisible", "ملف غير صالح", "Unreadable file"),
        "searching_for" to e("Recherche de", "البحث عن", "Searching for"),
        "no_title" to e("Titre introuvable", "تعذّر أخذ العنوان", "Title not found"),
        "no_subs" to e("Aucun sous-titre chargé", "لا توجد ترجمة", "No subtitles loaded"),
        "synced" to e("Synchronisé", "تمت المزامنة", "Synced"),
        "sync_scan" to e("Analyse de l'audio (vidéo en pause)…", "جارٍ تحليل الصوت (الفيديو متوقف)…", "Analyzing audio (video paused)…"),
        "sync_start" to e("Analyse… laissez un dialogue passer (60 s)", "جارٍ التحليل… اترك حوارًا يمر (60 ث)", "Analyzing… let some dialogue play (60 s)"),
        "sync_fail" to e("Synchro non fiable, réessayez pendant un dialogue", "المزامنة غير موثوقة، جرّب أثناء حوار", "Sync not reliable, retry during dialogue"),
        "sync_noaudio" to e("Audio non analysable (flux compressé)", "تعذّر تحليل الصوت (صوت مضغوط)", "Audio cannot be analyzed (compressed stream)"),
        "sync_busy" to e("Analyse en cours", "التحليل جارٍ", "Analysis in progress"),
        "locked_t" to e("Écran verrouillé", "الشاشة مقفلة", "Screen locked"),
        "unlocked_t" to e("Écran déverrouillé", "تم فتح القفل", "Screen unlocked"),
        "player_error" to e("Erreur", "خطأ", "Error"),
        "sample" to e("Exemple de sous-titre", "ترجمة تجريبية", "Sample subtitle"),
        "found" to e("trouvés", "نتيجة", "found"),
        // ---- main screen
        "tagline" to e("Recevez le flux de votre téléphone : DLNA et Chromecast", "استقبال البث من الهاتف: DLNA و Chromecast", "Receive streams from your phone: DLNA & Chromecast"),
        "status" to e("État", "الحالة", "Status"),
        "svc_on" to e("●  Service actif", "●  الخدمة تعمل", "●  Service running"),
        "addr" to e("Adresse de la box", "عنوان البوكس", "Box address"),
        "addr_hint" to e("Ouvrez cette adresse depuis le navigateur du téléphone pour envoyer un fichier de sous-titres", "افتح هذا العنوان من متصفح الهاتف لإرسال ملف ترجمة", "Open this address in your phone's browser to send a subtitle file"),
        "no_net" to e("Pas de réseau", "غير متصل بالشبكة", "No network"),
        "shown_as" to e("Visible sur le téléphone sous le nom", "يظهر في الهاتف باسم", "Shown on the phone as"),
        "overlay" to e("Affichage par-dessus les applis", "إذن الفتح فوق التطبيقات", "Display over other apps"),
        "overlay_hint" to e("Sans cela, le lecteur peut ne pas s'ouvrir si l'appli est fermée", "بدونه قد لا يفتح المشغّل إذا كان التطبيق مغلقًا", "Without it the player may not open while the app is closed"),
        "enabled" to e("Activé ✓", "مفعّل ✓", "Enabled ✓"),
        "disabled" to e("Désactivé ✗", "غير مفعّل ✗", "Disabled ✗"),
        "allow_overlay" to e("Autoriser l'affichage par-dessus", "السماح بالفتح فوق التطبيقات", "Allow display over apps"),
        "files" to e("Accès à tous les fichiers", "الوصول إلى الملفات", "All files access"),
        "files_hint" to e("Nécessaire pour chercher des sous-titres dans la box", "مطلوب للبحث عن ترجمات داخل البوكس", "Needed to search subtitles stored on the box"),
        "allow_files" to e("Autoriser l'accès aux fichiers", "السماح بالوصول إلى الملفات", "Allow file access"),
        "api_card" to e("Clé API OpenSubtitles", "مفتاح OpenSubtitles API", "OpenSubtitles API key"),
        "api_hint" to e("Optionnel : identifiant et mot de passe pour télécharger sans limite", "اختياري: اسم المستخدم وكلمة المرور لتنزيل أكثر", "Optional: username & password for more downloads"),
        "api_key" to e("Clé API", "مفتاح API", "API key"),
        "api_user" to e("Utilisateur (optionnel)", "اسم المستخدم (اختياري)", "Username (optional)"),
        "api_pass" to e("Mot de passe (optionnel)", "كلمة المرور (اختياري)", "Password (optional)"),
        "api_save" to e("Enregistrer", "حفظ", "Save"),
        "api_saved" to e("Enregistré ✓", "تم الحفظ ✓", "Saved ✓"),
        "src_api" to e("OpenSubtitles API", "OpenSubtitles API", "OpenSubtitles API"),
        "src_free" to e("OpenSubtitles (sans clé)", "OpenSubtitles (بدون مفتاح)", "OpenSubtitles (no key)"),
        "keys" to e("Touches de la télécommande", "أزرار الريموت أثناء التشغيل", "Remote keys while playing"),
        "k_seek" to e("◀ ▶   Reculer / avancer de 10 s", "◀ ▶   رجوع / تقديم 10 ثواني", "◀ ▶   Back / forward 10 s"),
        "k_ok" to e("OK   Pause + boutons (◀ ▶ pour naviguer)", "OK   إيقاف مؤقت + الأزرار (◀ ▶ للتنقل)", "OK   Pause + buttons (◀ ▶ to move)"),
        "k_up" to e("▲ ou MENU   Menu Options", "▲ أو MENU   قائمة الخيارات", "▲ or MENU   Options menu"),
        "k_back" to e("Retour   Fermer le menu / quitter", "رجوع   إغلاق القائمة / خروج", "Back   Close menu / exit"),
        "k_color" to e("Rouge / Vert   Décalage des sous-titres", "أحمر / أخضر   تقديم أو تأخير الترجمة", "Red / Green   Subtitle delay"),
        "diag" to e("Diagnostic Chromecast", "تشخيص Chromecast", "Chromecast diagnostics"),
        "cast_off" to e("Chromecast : arrêté (appuyez pour activer)", "Chromecast: متوقف (اضغط للتفعيل)", "Chromecast: off (press to enable)"),
        "cast_on" to e("Chromecast : actif (appuyez pour arrêter)", "Chromecast: مفعّل (اضغط للإيقاف)", "Chromecast: on (press to disable)"),
        "auth" to e("Vérification", "طريقة التحقق", "Verification"),
        "auth0" to e("Silence (sans réponse)", "صمت (بدون رد)", "Silent (no reply)"),
        "auth1" to e("Réponse signée (certificat auto)", "رد موقّع بشهادة ذاتية", "Self-signed reply"),
        "auth2" to e("Message d'erreur", "رسالة خطأ", "Error message"),
        "press_toggle" to e("Appuyez pour changer", "اضغط للتبديل", "Press to change"),
        "tls" to e("Profil sécurisé", "ملف الاتصال الآمن", "Secure profile"),
        "tls_hint" to e("Appuyez pour changer (relancez l'appli)", "اضغط للتبديل (يتطلب إعادة فتح التطبيق)", "Press to change (restart the app)"),
        "restart_hint" to e("Arrêtez l'application puis rouvrez-la", "أوقف التطبيق نهائيًا ثم افتحه ليُطبَّق", "Quit the app, then reopen it"),
        "quit_app" to e("Arrêter l'application", "إيقاف التطبيق نهائيًا", "Quit the app"),
        "crash" to e("Une erreur est survenue. Prenez une capture de cet écran et envoyez-la. (Chromecast désactivé temporairement)", "حدث خطأ وأُغلق التطبيق. صوّر هذه الشاشة وأرسلها لي. (تم إيقاف Chromecast مؤقتًا)", "An error occurred. Take a screenshot and send it. (Chromecast temporarily disabled)"),
        "crash_continue" to e("Continuer et effacer le rapport", "متابعة وحذف التقرير", "Continue and delete report")
    )
}
