package com.rakki.boxdlna

import androidx.media3.common.MimeTypes
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.nio.ByteBuffer
import java.nio.charset.CharacterCodingException
import java.nio.charset.Charset
import java.nio.charset.CodingErrorAction

object SubtitleLoader {
    class Sub(val file: File, val mime: String)

    fun fetch(url: String, dir: File, name: String = "remote"): Sub? = try {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 8000
        c.readTimeout = 10000
        c.instanceFollowRedirects = true
        c.setRequestProperty("User-Agent", "Mozilla/5.0")
        val bytes = c.inputStream.use { it.readBytes() }
        normalize(bytes, dir, name)
    } catch (e: Exception) { null }

    fun normalize(raw: ByteArray, dir: File, name: String): Sub? {
        if (raw.isEmpty() || raw.size > 5_000_000) return null
        val t = decode(raw).trimStart('\uFEFF').replace("\r\n", "\n").replace('\r', '\n')
        val ext: String
        val mime: String
        when {
            t.startsWith("WEBVTT") -> { ext = "vtt"; mime = MimeTypes.TEXT_VTT }
            t.contains("[Script Info]") -> { ext = "ssa"; mime = MimeTypes.TEXT_SSA }
            else -> { ext = "srt"; mime = MimeTypes.APPLICATION_SUBRIP }
        }
        dir.listFiles()?.filter { it.name.startsWith("$name-") }?.forEach { it.delete() }
        val f = File(dir, "$name-${System.nanoTime()}.$ext")
        f.writeText(t, Charsets.UTF_8)
        return Sub(f, mime)
    }

    private fun decode(b: ByteArray): String {
        if (b.size >= 3 && b[0] == 0xEF.toByte() && b[1] == 0xBB.toByte() && b[2] == 0xBF.toByte())
            return String(b, 3, b.size - 3, Charsets.UTF_8)
        if (b.size >= 2 && b[0] == 0xFF.toByte() && b[1] == 0xFE.toByte())
            return String(b, 2, b.size - 2, Charsets.UTF_16LE)
        if (b.size >= 2 && b[0] == 0xFE.toByte() && b[1] == 0xFF.toByte())
            return String(b, 2, b.size - 2, Charsets.UTF_16BE)
        try {
            return Charsets.UTF_8.newDecoder()
                .onMalformedInput(CodingErrorAction.REPORT)
                .onUnmappableCharacter(CodingErrorAction.REPORT)
                .decode(ByteBuffer.wrap(b)).toString()
        } catch (e: CharacterCodingException) { }
        val ar = String(b, Charset.forName("windows-1256"))
        val letters = ar.count { it.isLetter() }
        val arabic = ar.count { it in '\u0600'..'\u06FF' }
        return if (letters > 0 && arabic * 100 / letters > 30) ar
        else String(b, Charset.forName("windows-1252"))
    }
}
