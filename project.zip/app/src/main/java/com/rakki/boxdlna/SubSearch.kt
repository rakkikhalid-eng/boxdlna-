package com.rakki.boxdlna

import android.content.Context
import android.os.Environment
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLDecoder
import java.net.URLEncoder
import java.util.zip.GZIPInputStream

/** Finds subtitles on the box's storage and on OpenSubtitles, using the title sent by the phone. */
object SubSearch {
    class Q(val title: String, val name: String, val year: String, val season: Int, val episode: Int) {
        fun display(): String {
            var s = title
            if (year.isNotEmpty()) s += " ($year)"
            if (season > 0) s += " S%02dE%02d".format(season, episode)
            return s
        }
    }

    class Res(val label: String, val info: String, val file: File?, val url: String?, val fileId: Long = 0, val exact: Boolean = false)

    /** ISO 639-2 codes used by OpenSubtitles, in the order shown in the menu. */
    val langIds = listOf("ara", "fre", "eng")
    val langIso2 = listOf("ar", "fr", "en")

    // ------------------------------------------------------------------ title

    private val DC_TITLE = Regex("""<dc:title[^>]*>(.*?)</dc:title>""", setOf(RegexOption.DOT_MATCHES_ALL))
    private val SEASON = Regex(
        """(?i)(?<![a-z0-9])(?:s|season)[ ._-]*(\d{1,2})[ ._:,-]*(?:e|ep|episode)[ ._-]*(\d{1,3})(?![0-9])|(?<![0-9])(\d{1,2})x(\d{2,3})(?![0-9])|الموسم[ ]*(\d{1,2})[ ]*الحلقة[ ]*(\d{1,3})"""
    )
    private val YEAR = Regex("""(?<!\d)((?:19|20)\d{2})(?!\d)""")
    private val QUALITY = Regex(
        """(?i)\b(480p|576p|720p|1080p|2160p|4k|bluray|blu-ray|brrip|bdrip|webrip|web-dl|webdl|hdrip|hdtv|dvdrip|x264|x265|h264|h265|hevc|multi|vostfr|truefrench|vff|vfq)\b"""
    )

    fun rawTitle(): String {
        val m = DC_TITLE.find(Renderer.meta)
        if (m != null) {
            val t = unesc(m.groupValues[1]).trim()
            if (t.isNotEmpty()) return t
        }
        val u = Renderer.uri.substringBefore('?').substringAfterLast('/')
        return try { URLDecoder.decode(u, "UTF-8") } catch (e: Exception) { u }
    }

    private fun didl(tag: String): String? =
        Regex("<" + tag + "[^>]*>(.*?)</" + tag + ">", RegexOption.DOT_MATCHES_ALL).find(Renderer.meta)
            ?.groupValues?.get(1)?.let { unesc(it).trim() }?.takeIf { it.isNotEmpty() }

    /** Title + year + season/episode, using the sender's DIDL fields when it provides them. */
    fun current(): Q? {
        val raw = rawTitle()
        if (raw.isBlank()) return null
        var q = parse(raw)
        var title = q.title
        var name = q.name
        var year = q.year
        var season = q.season
        var episode = q.episode
        val series = didl("upnp:seriesTitle")
        val ds = didl("upnp:episodeSeason")?.toIntOrNull()
        val de = didl("upnp:episodeNumber")?.toIntOrNull()
        if (series != null) { val sq = parse(series); title = sq.title; name = sq.name }
        if (ds != null && ds > 0) season = ds
        if (de != null && de > 0) episode = de
        if (year.isEmpty()) {
            val d = didl("dc:date")
            val y = d?.let { YEAR.find(it)?.groupValues?.get(1) }
            if (y != null) year = y
        }
        if (Renderer.ovSeason >= 0) season = Renderer.ovSeason
        if (Renderer.ovEpisode >= 0) episode = Renderer.ovEpisode
        Renderer.ovYear?.let { year = it }
        if (season > 0 && episode == 0) episode = 1
        if (season == 0) episode = 0
        q = Q(title, name, year, season, episode)
        return q
    }

    fun parse(raw0: String): Q {
        var raw = raw0.trim()
        raw = raw.replace(Regex("""(?i)\.(mkv|mp4|avi|mov|m4v|wmv|flv|webm|ts|mpg|mpeg|srt|ass|vtt)$"""), "")
        val s = raw.replace(Regex("""[._\[\]()]+"""), " ").replace(Regex("""\s+"""), " ").trim()
        var season = 0
        var episode = 0
        var cut = s.length
        val sm = SEASON.find(s)
        if (sm != null) {
            val g = sm.groupValues
            when {
                g[1].isNotEmpty() -> { season = g[1].toInt(); episode = g[2].toInt() }
                g[3].isNotEmpty() -> { season = g[3].toInt(); episode = g[4].toInt() }
                else -> { season = g[5].toInt(); episode = g[6].toInt() }
            }
            cut = minOf(cut, sm.range.first)
        }
        var year = ""
        val ym = YEAR.find(s)
        if (ym != null && ym.range.first > 0) {
            year = ym.groupValues[1]
            cut = minOf(cut, ym.range.first)
        }
        val qm = QUALITY.find(s)
        if (qm != null && qm.range.first > 0) cut = minOf(cut, qm.range.first)
        var title = s.substring(0, cut).trim(' ', '-', ':')
        if (title.isEmpty()) title = s
        val name = title.lowercase().replace(Regex("""[^\p{L}\p{N} ]"""), " ").replace(Regex("""\s+"""), " ").trim()
        return Q(title, name, year, season, episode)
    }

    // ------------------------------------------------------------------ on the box

    private val EXT = setOf("srt", "vtt", "ass", "ssa")

    private fun roots(ctx: Context): List<File> {
        val out = LinkedHashSet<File>()
        val ext = Environment.getExternalStorageDirectory()
        for (d in listOf("Download", "Downloads", "Movies", "Subtitles", "Subs", "Documents", "Video", "Videos")) {
            out.add(File(ext, d))
        }
        out.add(ext)
        try {
            File("/storage").listFiles()?.forEach { v ->
                if (v.isDirectory && v.name != "self" && v.name != "emulated") {
                    out.add(v)
                    for (d in listOf("Subtitles", "Subs", "Movies", "Download")) out.add(File(v, d))
                }
            }
        } catch (e: Exception) { }
        ctx.getExternalFilesDir(null)?.let { out.add(it) }
        return out.filter { it.isDirectory }
    }

    private fun walk(dir: File, depth: Int, into: MutableList<File>, limit: Int) {
        if (into.size >= limit || depth < 0) return
        val kids = try { dir.listFiles() } catch (e: Exception) { null } ?: return
        for (f in kids) {
            if (into.size >= limit) return
            if (f.name.startsWith(".")) continue
            if (f.isDirectory) {
                if (f.name == "Android" || f.name == "cache") continue
                walk(f, depth - 1, into, limit)
            } else if (f.extension.lowercase() in EXT) into.add(f)
        }
    }

    fun searchLocal(ctx: Context, q: Q?): List<Res> {
        val found = ArrayList<File>()
        val seen = HashSet<String>()
        for (r in roots(ctx)) {
            val tmp = ArrayList<File>()
            walk(r, if (r == Environment.getExternalStorageDirectory()) 2 else 4, tmp, 4000)
            for (f in tmp) if (seen.add(f.absolutePath)) found.add(f)
        }
        val tokens = (q?.name ?: "").split(' ').filter { it.length > 1 }
        val scored = found.map { f ->
            val n = f.nameWithoutExtension.lowercase().replace(Regex("""[^\p{L}\p{N} ]"""), " ")
            var sc = tokens.count { n.contains(it) } * 10
            if (q != null && q.season > 0 && n.contains("s%02de%02d".format(q.season, q.episode))) sc += 15
            if (q != null && q.year.isNotEmpty() && n.contains(q.year)) sc += 3
            f to sc
        }
        val hit = if (tokens.isEmpty()) scored else scored.filter { it.second > 0 }
        return hit.sortedWith(compareByDescending<Pair<File, Int>> { it.second }.thenByDescending { it.first.lastModified() })
            .take(40)
            .map { (f, _) -> Res(f.name, f.parentFile?.name ?: "", f, null) }
    }

    // ------------------------------------------------------------------ file fingerprint (OpenSubtitles moviehash)

    private var hashUri = ""
    private var hashRes: Pair<String, Long>? = null

    /** Hash of the first/last 64 KB + size, read with HTTP Range requests. Null if the server can't do ranges. */
    fun fileHash(url: String): Pair<String, Long>? {
        if (!url.startsWith("http")) return null
        if (url == hashUri) return hashRes
        var out: Pair<String, Long>? = null
        try {
            val chunk = 65536
            val c1 = URL(url).openConnection() as HttpURLConnection
            c1.connectTimeout = 8000
            c1.readTimeout = 12000
            c1.setRequestProperty("Range", "bytes=0-" + (chunk - 1))
            if (c1.responseCode == 206) {
                val total = c1.getHeaderField("Content-Range")?.substringAfter('/')?.trim()?.toLongOrNull() ?: 0L
                val first = readFully(c1.inputStream, chunk)
                if (total >= chunk * 2L && first.size == chunk) {
                    val c2 = URL(url).openConnection() as HttpURLConnection
                    c2.connectTimeout = 8000
                    c2.readTimeout = 12000
                    c2.setRequestProperty("Range", "bytes=" + (total - chunk) + "-" + (total - 1))
                    if (c2.responseCode == 206) {
                        val last = readFully(c2.inputStream, chunk)
                        if (last.size == chunk) {
                            var h = total
                            for (b in listOf(first, last)) {
                                val lb = java.nio.ByteBuffer.wrap(b).order(java.nio.ByteOrder.LITTLE_ENDIAN).asLongBuffer()
                                while (lb.hasRemaining()) h += lb.get()
                            }
                            out = Pair(String.format("%016x", h), total)
                        }
                    }
                    c2.disconnect()
                }
            }
            c1.disconnect()
        } catch (e: Exception) { }
        hashUri = url
        hashRes = out
        return out
    }

    private fun readFully(i: java.io.InputStream, n: Int): ByteArray {
        val buf = ByteArray(n)
        var off = 0
        i.use { s -> while (off < n) { val r = s.read(buf, off, n - off); if (r < 0) break; off += r } }
        return if (off == n) buf else buf.copyOf(off)
    }

    // ------------------------------------------------------------------ OpenSubtitles

    private const val API = "https://api.opensubtitles.com/api/v1"
    private const val UA = "BoxDLNA v1.2"

    private fun httpJson(url: String, method: String, key: String, body: String?, token: String? = null): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 10000
        c.readTimeout = 20000
        c.requestMethod = method
        c.setRequestProperty("Api-Key", key)
        c.setRequestProperty("User-Agent", UA)
        c.setRequestProperty("Accept", "application/json")
        if (token != null) c.setRequestProperty("Authorization", "Bearer $token")
        if (body != null) {
            c.doOutput = true
            c.setRequestProperty("Content-Type", "application/json")
            c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
        }
        val stream = if (c.responseCode in 200..299) c.inputStream else (c.errorStream ?: throw RuntimeException("HTTP " + c.responseCode))
        val txt = stream.use { it.readBytes() }.toString(Charsets.UTF_8)
        if (c.responseCode !in 200..299) throw RuntimeException("HTTP " + c.responseCode + " " + txt.take(120))
        return txt
    }

    /** Hash matches first (exact same release = perfectly in sync), then title / year / season / episode matches. */
    fun searchOnline(ctx: Context, q: Q, lang: Int): List<Res> {
        val key = Cfg.apiKey(ctx)
        val h = try { fileHash(Renderer.uri) } catch (e: Exception) { null }
        val out = ArrayList<Res>()
        val seen = HashSet<String>()
        fun addAll(l: List<Res>) { for (r in l) if (seen.add(if (r.fileId != 0L) "f" + r.fileId else (r.url ?: r.label))) out.add(r) }
        if (key.isNotEmpty()) {
            if (h != null) try { addAll(searchApi(key, q, langIso2[lang], h.first)) } catch (e: Exception) { }
            addAll(searchApi(key, q, langIso2[lang], null))
        } else {
            if (h != null) try { addAll(searchLegacy(q, langIds[lang], h)) } catch (e: Exception) { }
            addAll(searchLegacy(q, langIds[lang], null))
        }
        return out.sortedByDescending { if (it.info.startsWith("🎯")) 2 else if (it.exact) 1 else 0 }.take(50)
    }

    private fun searchApi(key: String, q: Q, lang: String, hash: String?): List<Res> {
        // parameters in alphabetical order, lower case (as the API recommends)
        val sb = StringBuilder("$API/subtitles?")
        if (hash == null && q.season > 0) sb.append("episode_number=").append(q.episode).append('&')
        sb.append("languages=").append(lang)
        if (hash != null) sb.append("&moviehash=").append(hash)
        else {
            sb.append("&query=").append(URLEncoder.encode(q.name, "UTF-8"))
            if (q.season > 0) sb.append("&season_number=").append(q.season)
            sb.append("&type=").append(if (q.season > 0) "episode" else "movie")
            if (q.season == 0 && q.year.isNotEmpty()) sb.append("&year=").append(q.year)
        }
        val arr = JSONObject(httpJson(sb.toString(), "GET", key, null)).optJSONArray("data") ?: return emptyList()
        class Tmp(val r: Res, val dl: Int, val score: Int)
        val out = ArrayList<Tmp>()
        for (i in 0 until arr.length()) {
            val at = arr.getJSONObject(i).optJSONObject("attributes") ?: continue
            val files = at.optJSONArray("files") ?: continue
            if (files.length() == 0) continue
            val f = files.getJSONObject(0)
            val fd = at.optJSONObject("feature_details")
            val fy = fd?.optInt("year") ?: 0
            val fs = fd?.optInt("season_number") ?: 0
            val fe = fd?.optInt("episode_number") ?: 0
            val dl = at.optInt("download_count")
            val byHash = hash != null && at.optBoolean("moviehash_match", false)
            if (hash != null && !byHash) continue
            var exact = true
            if (q.season > 0) exact = fs == q.season && fe == q.episode
            else if (q.year.isNotEmpty() && fy != 0) exact = fy.toString() == q.year
            val title = fd?.optString("title").orEmpty().ifEmpty { fd?.optString("movie_name").orEmpty() }
            val ep = if (fs > 0) " S%02dE%02d".format(fs, fe) else ""
            val info = (title + (if (fy != 0) " $fy" else "") + ep + "  ⬇" + dl).trim()
            val name = f.optString("file_name").ifEmpty { at.optString("release") }
            val tag = if (byHash) "🎯 " + L.t("hash_hit") + " · " else if (exact) "✓ " else ""
            out.add(Tmp(Res(name, tag + info, null, null, f.optLong("file_id"), exact || byHash), dl, if (byHash) 200 else if (exact) 100 else 0))
        }
        return out.sortedWith(compareByDescending<Tmp> { it.score }.thenByDescending { it.dl }).take(40).map { it.r }
    }

    private fun searchLegacy(q: Q, langId: String, hash: Pair<String, Long>?): List<Res> {
        val sb = StringBuilder("https://rest.opensubtitles.org/search")
        if (hash != null) {
            sb.append("/moviebytesize-").append(hash.second).append("/moviehash-").append(hash.first)
        } else {
            if (q.season > 0) sb.append("/episode-").append(q.episode)
            sb.append("/query-").append(URLEncoder.encode(q.name, "UTF-8").replace("+", "%20"))
            if (q.season > 0) sb.append("/season-").append(q.season)
        }
        sb.append("/sublanguageid-").append(langId)
        val c = URL(sb.toString()).openConnection() as HttpURLConnection
        c.connectTimeout = 10000
        c.readTimeout = 15000
        c.setRequestProperty("User-Agent", "TemporaryUserAgent")
        val arr = JSONArray(c.inputStream.use { it.readBytes() }.toString(Charsets.UTF_8))
        class Tmp(val r: Res, val dl: Int, val score: Int)
        val list = ArrayList<Tmp>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val link = o.optString("SubDownloadLink")
            if (link.isEmpty()) continue
            val fmt = o.optString("SubFormat").lowercase()
            if (fmt.isNotEmpty() && fmt !in EXT) continue
            val dl = o.optString("SubDownloadsCnt").toIntOrNull() ?: 0
            val my = o.optString("MovieYear")
            val ss = o.optString("SeriesSeason").toIntOrNull() ?: 0
            val se = o.optString("SeriesEpisode").toIntOrNull() ?: 0
            val byHash = hash != null && o.optString("MatchedBy") == "moviehash"
            val exact = if (q.season > 0) (ss == q.season && se == q.episode) else (q.year.isEmpty() || my == q.year)
            val info = (o.optString("MovieName") + " " + my + "  ⬇" + dl).trim()
            val tag = if (byHash) "🎯 " + L.t("hash_hit") + " · " else if (exact) "✓ " else ""
            list.add(Tmp(Res(o.optString("SubFileName"), tag + info, null, link, 0, exact || byHash), dl, if (byHash) 200 else if (exact) 100 else 0))
        }
        return list.sortedWith(compareByDescending<Tmp> { it.score }.thenByDescending { it.dl }).take(40).map { it.r }
    }

    @Volatile private var token: String? = null

    private fun apiToken(ctx: Context, key: String): String? {
        val u = Cfg.user(ctx)
        val p = Cfg.pass(ctx)
        if (u.isEmpty() || p.isEmpty()) return null
        token?.let { return it }
        return try {
            val body = JSONObject().put("username", u).put("password", p).toString()
            val t = JSONObject(httpJson("$API/login", "POST", key, body)).optString("token")
            token = t.ifEmpty { null }
            token
        } catch (e: Exception) { null }
    }

    fun download(ctx: Context, r: Res, dir: File): SubtitleLoader.Sub? {
        val raw: ByteArray
        val url: String
        if (r.fileId != 0L) {
            val key = Cfg.apiKey(ctx)
            val body = JSONObject().put("file_id", r.fileId).toString()
            val resp = try {
                httpJson("$API/download", "POST", key, body, apiToken(ctx, key))
            } catch (e: Exception) { token = null; httpJson("$API/download", "POST", key, body, apiToken(ctx, key)) }
            url = JSONObject(resp).optString("link")
            if (url.isEmpty()) return null
        } else url = r.url ?: return null
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 10000
        c.readTimeout = 20000
        c.instanceFollowRedirects = true
        c.setRequestProperty("User-Agent", if (r.fileId != 0L) UA else "TemporaryUserAgent")
        raw = c.inputStream.use { it.readBytes() }
        val bytes = if (url.endsWith(".gz") || (raw.size > 2 && raw[0] == 0x1f.toByte() && raw[1] == 0x8b.toByte()))
            GZIPInputStream(raw.inputStream()).use { it.readBytes() } else raw
        return SubtitleLoader.normalize(bytes, dir, "manual")
    }
}
