package com.rakki.boxdlna

import android.content.Context
import android.os.Handler
import android.os.Looper
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.audio.AudioSink
import androidx.media3.exoplayer.audio.DefaultAudioSink
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory

/**
 * Listens to a window of the movie's audio with a hidden, muted, video-less player running at 4x speed,
 * so 60 s of dialogue take about 15 s and nothing is heard. Works with every source ExoPlayer can play (HLS too).
 * Must be started on the main thread; [onDone] is called on the main thread with the 10 ms bins, or null.
 */
class FastScan(
    private val ctx: Context,
    private val item: MediaItem,
    private val startMs: Long,
    private val durMs: Long,
    private val recordPcm: Boolean = false,
    private val onDone: (FloatArray?, ShortArray?) -> Unit
) {
    private val tap = AudioTap()
    private var player: ExoPlayer? = null
    private val h = Handler(Looper.getMainLooper())
    private var done = false
    private val t0 = System.currentTimeMillis()
    private val need = (durMs / 10).toInt()

    private val check = object : Runnable {
        override fun run() {
            if (done) return
            val have = tap.binCount()
            val timeout = System.currentTimeMillis() - t0 > 45_000
            when {
                have >= need -> finish(true)
                timeout -> finish(have >= need / 2)
                else -> h.postDelayed(this, 250)
            }
        }
    }

    fun start() {
        val rf = object : DefaultRenderersFactory(ctx) {
            override fun buildAudioSink(c: Context, enableFloatOutput: Boolean, enableAudioTrackPlaybackParams: Boolean): AudioSink =
                DefaultAudioSink.Builder(c)
                    .setEnableFloatOutput(false)
                    .setEnableAudioTrackPlaybackParams(false)
                    .setAudioProcessors(arrayOf(tap.processor))
                    .build()
        }.setEnableDecoderFallback(true)
        val http = DefaultHttpDataSource.Factory().setAllowCrossProtocolRedirects(true)
            .setUserAgent("Mozilla/5.0 (Linux; Android 11; Box) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Safari/537.36")
        val p = ExoPlayer.Builder(ctx, rf)
            .setMediaSourceFactory(DefaultMediaSourceFactory(DefaultDataSource.Factory(ctx, http)))
            .build()
        player = p
        p.trackSelectionParameters = p.trackSelectionParameters.buildUpon()
            .setTrackTypeDisabled(C.TRACK_TYPE_VIDEO, true)
            .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, true)
            .build()
        p.volume = 0f
        p.setPlaybackSpeed(4f)
        p.addListener(object : Player.Listener {
            override fun onPlayerError(error: PlaybackException) {
                CmdLog.add("sync scan error: " + error.errorCodeName)
                finish(false)
            }

            override fun onPlaybackStateChanged(state: Int) {
                if (state == Player.STATE_ENDED) finish(tap.binCount() >= need / 2)
            }
        })
        tap.recordPcm = recordPcm
        tap.begin(startMs)
        p.setMediaItem(item, startMs)
        p.prepare()
        p.playWhenReady = true
        h.post(check)
    }

    private fun release() {
        h.removeCallbacks(check)
        try { player?.release() } catch (e: Exception) { }
        player = null
    }

    private fun finish(ok: Boolean) {
        if (done) return
        done = true
        val bins = if (ok) tap.end() else { tap.collecting = false; null }
        val pcm = if (ok && recordPcm) tap.pcm16k() else null
        release()
        onDone(bins, pcm)
    }

    /** Stops without calling [onDone]. */
    fun cancel() {
        if (done) return
        done = true
        tap.collecting = false
        release()
    }
}
