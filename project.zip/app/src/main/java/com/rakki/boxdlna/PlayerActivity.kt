package com.rakki.boxdlna

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.util.TypedValue
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.CaptionStyleCompat
import androidx.media3.ui.PlayerView
import java.util.Locale
import kotlin.math.abs

class PlayerActivity : Activity() {
    var player: ExoPlayer? = null
    private lateinit var view: PlayerView
    private lateinit var root: FrameLayout
    private lateinit var cueView: CueView

    private var cues: List<CueParser.C> = emptyList()
    private var subOffsetMs = 0L
    private var lastUri = ""
    private var loadedSig = ""
    private var gen = 0
    private var aspect = 0
    private var lastToast: Toast? = null

    private val aspectNames = listOf("ملائمة", "ملء الشاشة (قص)", "تمديد", "16:9", "4:3")

    // ---------------------------------------------------------------- tickers

    private val ticker = object : Runnable {
        override fun run() {
            player?.let { p ->
                Renderer.posMs = p.currentPosition
                val d = p.duration
                Renderer.durMs = if (d == C.TIME_UNSET) 0L else d
            }
            Renderer.main.postDelayed(this, 500)
        }
    }

    private val cueTick = object : Runnable {
        override fun run() {
            updateCue()
            Renderer.main.postDelayed(this, 100)
        }
    }

    private fun activeText(t: Long): String {
        var lo = 0
        var hi = cues.size - 1
        var idx = -1
        while (lo <= hi) {
            val mid = (lo + hi) ushr 1
            if (cues[mid].s <= t) { idx = mid; lo = mid + 1 } else hi = mid - 1
        }
        if (idx < 0) return ""
        val sb = StringBuilder()
        var i = maxOf(0, idx - 3)
        while (i <= idx) {
            if (cues[i].e > t) {
                if (sb.isNotEmpty()) sb.append('\n')
                sb.append(cues[i].t)
            }
            i++
        }
        return sb.toString()
    }

    private fun updateCue() {
        val p = player
        var txt = if (p == null || cues.isEmpty()) "" else activeText(p.currentPosition - subOffsetMs)
        if (txt.isEmpty() && panelOpen()) txt = "ترجمة تجريبية - Sample subtitle"
        if (txt != cueView.text) {
            cueView.text = txt
            cueView.invalidate()
        }
    }

    // ---------------------------------------------------------------- player events

    private val listener = object : Player.Listener {
        override fun onPlaybackStateChanged(playbackState: Int) { sync() }
        override fun onPlayWhenReadyChanged(playWhenReady: Boolean, reason: Int) { sync() }
        override fun onPlayerError(error: PlaybackException) {
            toast("خطأ: " + error.errorCodeName)
            Renderer.state = "STOPPED"
            Renderer.changed()
            Renderer.main.postDelayed({ finish() }, 3500)
        }
    }

    private fun sync() {
        val p = player ?: return
        val st = when (p.playbackState) {
            Player.STATE_BUFFERING -> "TRANSITIONING"
            Player.STATE_READY -> if (p.playWhenReady) "PLAYING" else "PAUSED_PLAYBACK"
            else -> "STOPPED"
        }
        if (Renderer.state != st) { Renderer.state = st; Renderer.changed() }
        if (p.playbackState == Player.STATE_ENDED) finish()
    }

    private fun toast(s: String) {
        lastToast?.cancel()
        lastToast = Toast.makeText(this, s, Toast.LENGTH_SHORT)
        lastToast?.show()
    }

    // ---------------------------------------------------------------- lifecycle

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        root = FrameLayout(this)
        root.setBackgroundColor(Color.BLACK)
        view = PlayerView(this)
        view.setShowBuffering(PlayerView.SHOW_BUFFERING_WHEN_PLAYING)
        root.addView(view, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        cueView = CueView(this)
        root.addView(cueView, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        setContentView(root)
        buildPanel()
        buildBar()
        aspect = SubStyle.aspect(this)
        applyStyle()
        root.post { applyAspect() }

        val http = DefaultHttpDataSource.Factory().setAllowCrossProtocolRedirects(true)
        val p = ExoPlayer.Builder(this, DefaultRenderersFactory(this).setEnableDecoderFallback(true))
            .setMediaSourceFactory(DefaultMediaSourceFactory(DefaultDataSource.Factory(this, http)))
            .build()
        p.addListener(listener)
        view.player = p
        player = p
        Renderer.activity = this
        Renderer.main.post(ticker)
        Renderer.main.post(cueTick)
        load(Renderer.wantPlay, takeStart())
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        onPlayRequest()
    }

    override fun onDestroy() {
        Renderer.main.removeCallbacks(ticker)
        Renderer.main.removeCallbacks(cueTick)
        Renderer.main.removeCallbacks(hideBar)
        player?.release()
        player = null
        if (Renderer.activity === this) {
            Renderer.activity = null
            Renderer.wantPlay = false
            if (Renderer.uri.isNotEmpty()) Renderer.state = "STOPPED"
            Renderer.changed()
        }
        super.onDestroy()
    }

    private fun takeStart(): Long {
        val s = Renderer.startMs
        Renderer.startMs = 0
        return s
    }

    fun onPlayRequest() {
        val p = player ?: return
        if (Renderer.signature() != loadedSig) load(true, takeStart()) else p.play()
    }

    fun reloadSubs() {
        if (player == null) return
        loadedSig = Renderer.signature()
        Thread {
            val sub = Renderer.effectiveManual() ?: Renderer.subUrl?.let { SubtitleLoader.fetch(it, cacheDir) }
            val parsed = try { if (sub != null) CueParser.parse(sub.file.readText()) else emptyList() } catch (t: Throwable) { emptyList() }
            runOnUiThread { if (!isFinishing && !isDestroyed) cues = parsed }
        }.start()
    }

    private fun load(autoplay: Boolean, startMs: Long) {
        val u = Renderer.uri
        if (u.isEmpty()) { finish(); return }
        if (u != lastUri) { subOffsetMs = 0; lastUri = u }
        loadedSig = Renderer.signature()
        val g = ++gen
        Thread {
            val sub = Renderer.effectiveManual() ?: Renderer.subUrl?.let { SubtitleLoader.fetch(it, cacheDir) }
            val parsed = try { if (sub != null) CueParser.parse(sub.file.readText()) else emptyList() } catch (t: Throwable) { emptyList() }
            runOnUiThread {
                if (!isFinishing && !isDestroyed && g == gen) {
                    cues = parsed
                    start(u, autoplay, startMs)
                }
            }
        }.start()
    }

    private fun start(u: String, autoplay: Boolean, startMs: Long) {
        val p = player ?: return
        p.setMediaItem(MediaItem.fromUri(u), startMs)
        p.prepare()
        p.playWhenReady = autoplay
    }

    // ---------------------------------------------------------------- picture size

    private fun applyAspect() {
        val w = root.width
        val h = root.height
        if (w == 0 || h == 0) { root.post { applyAspect() }; return }
        var lp = FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT, Gravity.CENTER)
        when (aspect) {
            0 -> view.resizeMode = AspectRatioFrameLayout.RESIZE_MODE_FIT
            1 -> view.resizeMode = AspectRatioFrameLayout.RESIZE_MODE_ZOOM
            2 -> view.resizeMode = AspectRatioFrameLayout.RESIZE_MODE_FILL
            else -> {
                val r = if (aspect == 3) 16f / 9f else 4f / 3f
                var bw = w
                var bh = (w / r).toInt()
                if (bh > h) { bh = h; bw = (h * r).toInt() }
                lp = FrameLayout.LayoutParams(bw, bh, Gravity.CENTER)
                view.resizeMode = AspectRatioFrameLayout.RESIZE_MODE_FILL
            }
        }
        view.layoutParams = lp
    }

    private fun setAspect(i: Int) {
        aspect = ((i % 5) + 5) % 5
        SubStyle.setAspect(this, aspect)
        applyAspect()
        toast("الصورة: " + aspectNames[aspect])
        refreshPanel()
    }

    // ---------------------------------------------------------------- subtitle style / sync

    fun applyStyle() {
        val st = SubStyle.get(this)
        cueView.sizeSp = st.size
        cueView.fillColor = st.color
        cueView.bgArgb = SubStyle.bgArgb(st)
        cueView.outline = st.edge
        cueView.bottomFraction = st.pos / 100f
        cueView.invalidate()
        view.subtitleView?.apply {
            setApplyEmbeddedStyles(false)
            setApplyEmbeddedFontSizes(false)
            setFixedTextSize(TypedValue.COMPLEX_UNIT_SP, st.size)
            setBottomPaddingFraction(st.pos / 100f)
            setStyle(
                CaptionStyleCompat(
                    st.color, SubStyle.bgArgb(st), Color.TRANSPARENT,
                    if (st.edge) CaptionStyleCompat.EDGE_TYPE_OUTLINE else CaptionStyleCompat.EDGE_TYPE_NONE,
                    Color.BLACK, null
                )
            )
        }
    }

    private fun offsetText(): String = String.format(Locale.US, "%+.1f ث", subOffsetMs / 1000.0)

    private fun nudge(ms: Long) {
        subOffsetMs = (subOffsetMs + ms).coerceIn(-600_000L, 600_000L)
        updateCue()
        refreshPanel()
    }

    private fun snapNearest() {
        val p = player ?: return
        if (cues.isEmpty()) { toast("لا توجد ترجمة"); return }
        val t = p.currentPosition - subOffsetMs
        var best = cues[0]
        var bd = Long.MAX_VALUE
        for (c in cues) {
            val d = abs(c.s - t)
            if (d < bd) { bd = d; best = c }
        }
        subOffsetMs = p.currentPosition - best.s
        updateCue()
        refreshPanel()
        toast("تمت المزامنة: " + offsetText())
    }

    // ---------------------------------------------------------------- on-screen menu

    private var panelScroll: ScrollView? = null
    private val rowViews = ArrayList<TextView>()
    private val rowBoxes = ArrayList<LinearLayout>()
    private var bar: LinearLayout? = null
    private val hideBar = Runnable { bar?.visibility = View.GONE }
    private var sel = 0

    private class Row(val label: String, val text: () -> String, val change: (Int) -> Unit)

    private val textColors = listOf(
        "#FFFFFF" to "أبيض", "#FFFF00" to "أصفر", "#00FFFF" to "سماوي",
        "#00FF00" to "أخضر", "#FFA500" to "برتقالي", "#CCCCCC" to "رمادي فاتح"
    ).map { Color.parseColor(it.first) to it.second }

    private val bgColors = listOf(
        "#000000" to "أسود", "#333333" to "رمادي غامق", "#0D47A1" to "أزرق",
        "#FFFFFF" to "أبيض", "#B71C1C" to "أحمر داكن"
    ).map { Color.parseColor(it.first) to it.second }

    private fun cname(c: Int, pal: List<Pair<Int, String>>): String =
        pal.firstOrNull { (it.first and 0xFFFFFF) == (c and 0xFFFFFF) }?.second ?: "مخصص"

    private fun cycle(c: Int, pal: List<Pair<Int, String>>, d: Int): Int {
        if (d == 0) return c
        val i = pal.indexOfFirst { (it.first and 0xFFFFFF) == (c and 0xFFFFFF) }
        val n = if (i < 0) 0 else (i + d + pal.size) % pal.size
        return pal[n].first
    }

    private fun edit(f: (SubStyle.S) -> SubStyle.S) {
        val n = f(SubStyle.get(this))
        SubStyle.save(this, n.size, n.color, n.bg, n.opacity, n.pos, n.edge)
        applyStyle()
        refreshPanel()
    }

    private val rows: List<Row> by lazy {
        listOf(
            Row("حجم الصورة", { aspectNames[aspect] }) { d -> setAspect(aspect + (if (d == 0) 1 else d)) },
            Row("تأخير الترجمة (OK = تصفير)", { offsetText() }) { d ->
                if (d == 0) { subOffsetMs = 0; updateCue(); refreshPanel() } else nudge(d * 100L)
            },
            Row("مزامنة سريعة: اضغط OK لحظة سماع جملة", { "" }) { d -> if (d == 0) snapNearest() },
            Row("حجم الخط", { SubStyle.get(this).size.toInt().toString() }) { d ->
                edit { it.copy(size = (it.size + 2 * d).coerceIn(14f, 70f)) }
            },
            Row("لون الخط", { cname(SubStyle.get(this).color, textColors) }) { d ->
                edit { it.copy(color = cycle(it.color, textColors, d)) }
            },
            Row("لون الخلفية", { cname(SubStyle.get(this).bg, bgColors) }) { d ->
                edit { it.copy(bg = cycle(it.bg, bgColors, d)) }
            },
            Row("كثافة الخلفية", {
                val o = SubStyle.get(this).opacity
                if (o == 0) "شفافة" else "$o%"
            }) { d -> edit { it.copy(opacity = (it.opacity + 10 * d).coerceIn(0, 100)) } },
            Row("ارتفاع الترجمة", { SubStyle.get(this).pos.toString() + "%" }) { d ->
                edit { it.copy(pos = (it.pos + 2 * d).coerceIn(0, 60)) }
            },
            Row("حواف الحروف", { if (SubStyle.get(this).edge) "نعم" else "لا" }) { d ->
                edit { it.copy(edge = if (d == 0) !it.edge else d > 0) }
            },
            Row("إعادة ضبط شكل الترجمة (OK)", { "" }) { d ->
                if (d == 0) { SubStyle.reset(this); applyStyle(); refreshPanel() }
            },
            Row("إيقاف التطبيق نهائيًا (OK)", { "" }) { d -> if (d == 0) AppQuit.quit(this) },
            Row("إغلاق القائمة (OK)", { "" }) { d -> if (d == 0) closePanel() }
        )
    }

    private fun panelOpen(): Boolean = panelScroll?.visibility == View.VISIBLE

    private fun stepBtn(text: String, f: () -> Unit): TextView {
        val dp = resources.displayMetrics.density
        val t = TextView(this)
        t.text = text
        t.textSize = 24f
        t.gravity = Gravity.CENTER
        t.setTextColor(Color.WHITE)
        val g = GradientDrawable()
        g.setColor(Color.parseColor("#33FFFFFF"))
        g.cornerRadius = 10 * dp
        t.background = g
        t.isClickable = true
        t.setOnClickListener { f(); refreshPanel() }
        return t
    }

    private fun buildPanel() {
        val dp = resources.displayMetrics.density
        val list = LinearLayout(this)
        list.orientation = LinearLayout.VERTICAL
        list.setPadding((14 * dp).toInt(), (10 * dp).toInt(), (14 * dp).toInt(), (10 * dp).toInt())
        list.layoutDirection = View.LAYOUT_DIRECTION_RTL

        val title = TextView(this)
        title.text = "قائمة المشغّل"
        title.textSize = 21f
        title.setTextColor(Color.WHITE)
        title.setPadding(0, 0, 0, (6 * dp).toInt())
        list.addView(title)

        for ((i, r) in rows.withIndex()) {
            val box = LinearLayout(this)
            box.orientation = LinearLayout.HORIZONTAL
            box.layoutDirection = View.LAYOUT_DIRECTION_LTR
            box.gravity = Gravity.CENTER_VERTICAL
            box.setPadding(0, (3 * dp).toInt(), 0, (3 * dp).toInt())
            val hasValue = r.text().isNotEmpty()
            val minus = stepBtn("−") { sel = i; r.change(-1) }
            val plus = stepBtn("+") { sel = i; r.change(1) }
            val center = TextView(this)
            center.textSize = 17f
            center.setTextColor(Color.WHITE)
            center.gravity = Gravity.CENTER
            center.setPadding((6 * dp).toInt(), (10 * dp).toInt(), (6 * dp).toInt(), (10 * dp).toInt())
            center.isClickable = true
            center.setOnClickListener { sel = i; r.change(0); refreshPanel() }
            if (!hasValue) {
                minus.visibility = View.INVISIBLE
                plus.visibility = View.INVISIBLE
            }
            box.addView(minus, LinearLayout.LayoutParams((48 * dp).toInt(), (44 * dp).toInt()))
            box.addView(center, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            box.addView(plus, LinearLayout.LayoutParams((48 * dp).toInt(), (44 * dp).toInt()))
            list.addView(box)
            rowBoxes.add(box)
            rowViews.add(center)
        }

        val hint = TextView(this)
        hint.text = "ريموت: ▲▼ تنقّل   ◀▶ تغيير   رجوع = إغلاق      لمس: − و + أو اضغط الصف"
        hint.textSize = 12f
        hint.setTextColor(Color.LTGRAY)
        hint.setPadding(0, (6 * dp).toInt(), 0, 0)
        list.addView(hint)

        val sv = ScrollView(this)
        sv.setBackgroundColor(Color.parseColor("#E6101010"))
        sv.visibility = View.GONE
        sv.addView(list)
        val pw = minOf((460 * dp).toInt(), (resources.displayMetrics.widthPixels * 0.92f).toInt())
        val lp = FrameLayout.LayoutParams(pw, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.RIGHT or Gravity.CENTER_VERTICAL)
        lp.topMargin = (12 * dp).toInt()
        lp.bottomMargin = (12 * dp).toInt()
        root.addView(sv, lp)
        panelScroll = sv
    }

    private fun refreshPanel() {
        if (rowViews.isEmpty()) return
        for (i in rows.indices) {
            val r = rows[i]
            val v = r.text()
            rowViews[i].text = if (v.isEmpty()) r.label else r.label + ":  " + v
            rowBoxes[i].setBackgroundColor(if (i == sel) Color.parseColor("#FF1565C0") else Color.TRANSPARENT)
        }
        val sv = panelScroll ?: return
        val box = rowBoxes[sel]
        sv.post { sv.smoothScrollTo(0, maxOf(0, box.top - sv.height / 2 + box.height / 2)) }
    }

    // ---------------------------------------------------------------- touch toolbar

    private fun tbBtn(text: String, f: () -> Unit): TextView {
        val dp = resources.displayMetrics.density
        val t = TextView(this)
        t.text = text
        t.textSize = 16f
        t.setTextColor(Color.WHITE)
        t.gravity = Gravity.CENTER
        t.setPadding((14 * dp).toInt(), (10 * dp).toInt(), (14 * dp).toInt(), (10 * dp).toInt())
        t.isClickable = true
        t.setOnClickListener { f(); showBar() }
        return t
    }

    private fun buildBar() {
        val dp = resources.displayMetrics.density
        val b = LinearLayout(this)
        b.orientation = LinearLayout.HORIZONTAL
        b.setBackgroundColor(Color.parseColor("#CC111111"))
        b.visibility = View.GONE
        b.addView(tbBtn("⏪ 10") { seekBy(-10_000) })
        b.addView(tbBtn("⏯") { player?.let { if (it.playWhenReady) it.pause() else it.play() } })
        b.addView(tbBtn("10 ⏩") { seekBy(10_000) })
        b.addView(tbBtn("الصورة") { setAspect(aspect + 1) })
        b.addView(tbBtn("الترجمة") { openPanel() })
        b.addView(tbBtn("⏹") { Renderer.stop() })
        val lp = FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP or Gravity.CENTER_HORIZONTAL)
        lp.topMargin = (10 * dp).toInt()
        root.addView(b, lp)
        bar = b
    }

    private fun showBar() {
        bar?.visibility = View.VISIBLE
        Renderer.main.removeCallbacks(hideBar)
        Renderer.main.postDelayed(hideBar, 4500)
    }

    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        if (ev.action == MotionEvent.ACTION_UP) {
            val ps = panelScroll
            if (ps != null && panelOpen()) {
                if (ev.x < ps.left) closePanel()
            } else showBar()
        }
        return super.dispatchTouchEvent(ev)
    }

    private fun openPanel() {
        sel = 0
        panelScroll?.visibility = View.VISIBLE
        view.hideController()
        refreshPanel()
        updateCue()
    }

    private fun closePanel() {
        panelScroll?.visibility = View.GONE
        updateCue()
    }

    // ---------------------------------------------------------------- remote control

    private fun seekBy(ms: Long) {
        val p = player ?: return
        val d = p.duration
        var t = p.currentPosition + ms
        if (t < 0) t = 0
        if (d != C.TIME_UNSET && t > d - 1000) t = maxOf(d - 1000, 0L)
        p.seekTo(t)
        view.showController()
    }

    private val panelKeys = setOf(
        KeyEvent.KEYCODE_DPAD_UP, KeyEvent.KEYCODE_DPAD_DOWN, KeyEvent.KEYCODE_DPAD_LEFT,
        KeyEvent.KEYCODE_DPAD_RIGHT, KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER,
        KeyEvent.KEYCODE_BACK, KeyEvent.KEYCODE_MENU
    )

    private val playerKeys = setOf(
        KeyEvent.KEYCODE_DPAD_LEFT, KeyEvent.KEYCODE_DPAD_RIGHT, KeyEvent.KEYCODE_DPAD_UP,
        KeyEvent.KEYCODE_DPAD_DOWN, KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER,
        KeyEvent.KEYCODE_MENU, KeyEvent.KEYCODE_SETTINGS, KeyEvent.KEYCODE_MEDIA_FAST_FORWARD,
        KeyEvent.KEYCODE_MEDIA_REWIND, KeyEvent.KEYCODE_PROG_RED, KeyEvent.KEYCODE_PROG_GREEN
    )

    override fun dispatchKeyEvent(e: KeyEvent): Boolean {
        val k = e.keyCode
        val open = panelOpen()
        val mine = if (open) k in panelKeys else k in playerKeys
        if (!mine) return super.dispatchKeyEvent(e)
        if (e.action == KeyEvent.ACTION_DOWN) {
            if (open) panelKey(k) else playerKey(k)
        }
        return true
    }

    private fun playerKey(k: Int) {
        val p = player ?: return
        showBar()
        when (k) {
            KeyEvent.KEYCODE_DPAD_LEFT, KeyEvent.KEYCODE_MEDIA_REWIND -> seekBy(-10_000)
            KeyEvent.KEYCODE_DPAD_RIGHT, KeyEvent.KEYCODE_MEDIA_FAST_FORWARD -> seekBy(10_000)
            KeyEvent.KEYCODE_DPAD_UP -> setAspect(aspect + 1)
            KeyEvent.KEYCODE_PROG_RED -> { nudge(-500); toast("الترجمة: " + offsetText()) }
            KeyEvent.KEYCODE_PROG_GREEN -> { nudge(500); toast("الترجمة: " + offsetText()) }
            KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER -> {
                if (p.playWhenReady) p.pause() else p.play()
                view.showController()
            }
            else -> openPanel()
        }
    }

    private fun panelKey(k: Int) {
        val n = rows.size
        when (k) {
            KeyEvent.KEYCODE_DPAD_UP -> { sel = (sel - 1 + n) % n; refreshPanel() }
            KeyEvent.KEYCODE_DPAD_DOWN -> { sel = (sel + 1) % n; refreshPanel() }
            KeyEvent.KEYCODE_DPAD_LEFT -> rows[sel].change(-1)
            KeyEvent.KEYCODE_DPAD_RIGHT -> rows[sel].change(1)
            KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER -> rows[sel].change(0)
            else -> closePanel()
        }
    }
}
