package com.rakki.boxdlna

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.text.Layout
import android.text.StaticLayout
import android.text.TextDirectionHeuristics
import android.text.TextPaint
import android.util.TypedValue
import android.view.View

/** Draws the current subtitle line (with outline and optional background box). */
class CueView(ctx: Context) : View(ctx) {
    var text = ""
    var sizeSp = 26f
    var fillColor = Color.WHITE
    var bgArgb = 0
    var outline = true
    var bottomFraction = 0.08f

    private val fillPaint = TextPaint(Paint.ANTI_ALIAS_FLAG)
    private val strokePaint = TextPaint(Paint.ANTI_ALIAS_FLAG)
    private val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG)

    private fun layout(s: String, p: TextPaint, w: Int): StaticLayout =
        StaticLayout.Builder.obtain(s, 0, s.length, p, w)
            .setAlignment(Layout.Alignment.ALIGN_CENTER)
            .setTextDirection(TextDirectionHeuristics.FIRSTSTRONG_LTR)
            .build()

    override fun onDraw(c: Canvas) {
        val s = text
        if (s.isEmpty() || width == 0) return
        val px = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_SP, sizeSp, resources.displayMetrics)
        fillPaint.textSize = px
        fillPaint.color = fillColor
        strokePaint.textSize = px
        strokePaint.color = Color.BLACK
        strokePaint.style = Paint.Style.STROKE
        strokePaint.strokeWidth = px / 6f
        strokePaint.strokeJoin = Paint.Join.ROUND

        val maxW = (width * 0.9f).toInt()
        val fl = layout(s, fillPaint, maxW)
        var lw = 0f
        for (i in 0 until fl.lineCount) lw = maxOf(lw, fl.getLineWidth(i))
        val x = (width - maxW) / 2f
        val y = maxOf(0f, height - height * bottomFraction - fl.height)
        val pad = px * 0.25f

        if ((bgArgb ushr 24) != 0) {
            bgPaint.color = bgArgb
            val cx = width / 2f
            c.drawRoundRect(cx - lw / 2 - pad, y - pad, cx + lw / 2 + pad, y + fl.height + pad, pad, pad, bgPaint)
        }
        c.save()
        c.translate(x, y)
        if (outline) layout(s, strokePaint, maxW).draw(c)
        fl.draw(c)
        c.restore()
    }
}
