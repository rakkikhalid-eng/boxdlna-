package com.rakki.boxdlna

import androidx.media3.common.MimeTypes
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.ConcurrentHashMap

/**
 * Looks at the first bytes of a link to learn what it really is (HLS playlist, DASH manifest, web page...), because
 * file extensions are often missing or misleading. Used to open the link as the right kind of stream and to give an
 * accurate message when a "video" link actually returns a web page.
 */
object Sniff {
    class Result(val mime: String?, val html: Boolean, val status: Int, val contentType: String)

    private val cache = ConcurrentHashMap<String, Result>()

    fun cached(u: String): Result? = cache[u]
    fun forget(u: String) { cache.remove(u) }

    fun detect(u: String): Result? {
        if (!u.startsWith("http")) return null
        cache[u]?.let { return it }
        return try {
            val c = URL(u).openConnection() as HttpURLConnection
            c.connectTimeout = 8000
            c.readTimeout = 8000
            c.instanceFollowRedirects = true
            c.setRequestProperty("User-Agent", Net.userAgent())
            for ((k, v) in Net.headers(u)) c.setRequestProperty(k, v)
            c.setRequestProperty("Range", "bytes=0-2047")
            val status = c.responseCode
            val ct = (c.contentType ?: "").lowercase()
            val head = if (status in 200..299) c.inputStream.use { s ->
                val b = ByteArray(2048)
                val n = s.read(b)
                if (n > 0) String(b, 0, n, Charsets.ISO_8859_1) else ""
            } else ""
            c.disconnect()
            val t = head.trimStart('\uFEFF', ' ', '\n', '\r', '\t')
            val mime = when {
                t.startsWith("#EXTM3U") || ct.contains("mpegurl") -> MimeTypes.APPLICATION_M3U8
                t.contains("<MPD") || ct.contains("dash+xml") -> MimeTypes.APPLICATION_MPD
                else -> null
            }
            val html = mime == null && (t.startsWith("<!DOCTYPE", true) || t.startsWith("<html", true) || ct.startsWith("text/html"))
            val r = Result(mime, html, status, ct)
            if (status in 200..299) cache[u] = r
            r
        } catch (e: Exception) { null }
    }
}
