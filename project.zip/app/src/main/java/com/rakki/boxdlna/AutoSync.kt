package com.rakki.boxdlna

import androidx.media3.common.C
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.audio.BaseAudioProcessor
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.abs
import kotlin.math.sqrt

/** Collects 10 ms RMS bins (voice band) of the audio that flows through one player's audio sink. */
class AudioTap {
    private val lock = Any()
    private val bins = ArrayList<Float>()
    private var curSum = 0.0
    private var curCnt = 0
    private var binFrames = 480
    private var channels = 2
    private var encoding = C.ENCODING_PCM_16BIT
    private var filt = AutoSync.Filt(48000)

    @Volatile var collecting = false
    @Volatile var pendingRefMs = 0L
    @Volatile var refMs = 0L

    fun begin(posMs: Long) {
        synchronized(lock) { bins.clear(); curSum = 0.0; curCnt = 0 }
        pendingRefMs = posMs
        refMs = posMs
        collecting = true
    }

    fun end(): FloatArray {
        collecting = false
        synchronized(lock) { return bins.toFloatArray() }
    }

    fun binCount(): Int = synchronized(lock) { bins.size }

    val processor: AudioProcessor = object : BaseAudioProcessor() {
        override fun onConfigure(inputAudioFormat: AudioProcessor.AudioFormat): AudioProcessor.AudioFormat {
            encoding = inputAudioFormat.encoding
            channels = maxOf(1, inputAudioFormat.channelCount)
            binFrames = maxOf(1, inputAudioFormat.sampleRate / 100)
            filt = AutoSync.Filt(maxOf(8000, inputAudioFormat.sampleRate))
            return inputAudioFormat
        }

        override fun queueInput(inputBuffer: ByteBuffer) {
            val n = inputBuffer.remaining()
            if (n == 0) return
            if (collecting && encoding == C.ENCODING_PCM_16BIT) {
                try { analyze(inputBuffer.duplicate()) } catch (e: Exception) { }
            }
            val out = replaceOutputBuffer(n)
            out.put(inputBuffer)
            out.flip()
        }

        override fun onFlush() {
            if (collecting) {
                synchronized(lock) { bins.clear(); curSum = 0.0; curCnt = 0 }
                refMs = pendingRefMs
            }
        }
    }

    private fun analyze(b: ByteBuffer) {
        b.order(ByteOrder.LITTLE_ENDIAN)
        val sb = b.asShortBuffer()
        synchronized(lock) {
            while (sb.remaining() >= channels) {
                var acc = 0
                for (i in 0 until channels) acc += sb.get().toInt()
                val m = filt.f(acc.toDouble() / channels / 32768.0)
                curSum += m * m
                curCnt++
                if (curCnt >= binFrames) {
                    bins.add(sqrt(curSum / curCnt).toFloat())
                    curSum = 0.0
                    curCnt = 0
                }
            }
        }
    }
}

/**
 * Automatic subtitle sync without any server: speech activity measured on the audio is matched with the
 * on-screen times of the subtitle lines.
 */
object AutoSync {
    /** Tap used by the visible player for the real-time fallback. */
    val rt = AudioTap()

    /** Voice band-pass (about 300-3400 Hz) so music bass and hiss count less than dialogue. */
    class Filt(rate: Int) {
        private val dt = 1.0 / rate
        private val aH = (1.0 / (2 * Math.PI * 300)).let { it / (it + dt) }
        private val aL = dt / ((1.0 / (2 * Math.PI * 3400)) + dt)
        private var px = 0.0
        private var hy = 0.0
        private var ly = 0.0
        fun f(x: Double): Double {
            hy = aH * (hy + x - px)
            px = x
            ly += aL * (hy - ly)
            return ly
        }
    }

    class Window(val startMs: Long, val bins: FloatArray)

    /** status: 0 = not reliable, 1 = offset found, 2 = already in sync. */
    class Outcome(val status: Int, val offsetMs: Long, val agree: Int, val total: Int)

    class Cand(val k: Int, val best: Float, val atCenter: Float, val z: Float)

    private fun smooth3(x: FloatArray): FloatArray =
        FloatArray(x.size) { i -> (x.getOrElse(i - 1) { x[i] } + x[i] + x.getOrElse(i + 1) { x[i] }) / 3f }

    /**
     * Scores every shift in +-range (100 ms steps) around [center] with two features:
     * (1) speech presence vs subtitle presence, (2) speech on/off edges vs subtitle start/end edges.
     */
    fun analyzeWindow(w: Window, cues: List<CueParser.C>, center: Int, range: Int = 900): Cand? {
        val bins = w.bins
        val n = bins.size / 10
        if (n < 300) return null
        val e = FloatArray(n)
        for (i in 0 until n) {
            var s = 0f
            for (j in 0 until 10) s += kotlin.math.ln(bins[i * 10 + j] + 1e-4f)
            e[i] = s / 10f
        }
        val sorted = e.sortedArray()
        val lo = sorted[(n * 0.2).toInt()]
        val hi = sorted[(n * 0.9).toInt().coerceAtMost(n - 1)]
        if (hi - lo < 0.3f) return null
        val thr = lo + 0.4f * (hi - lo)
        val raw = FloatArray(n) { if (e[it] > thr) 1f else 0f }
        val a = FloatArray(n) { i ->
            val c = raw[i] + raw.getOrElse(i - 1) { raw[i] } + raw.getOrElse(i + 1) { raw[i] }
            if (c >= 2f) 1f else 0f
        }
        val aMean = a.average().toFloat()
        if (aMean < 0.08f || aMean > 0.92f) return null
        val varA = aMean * (1 - aMean)
        val sa = smooth3(a)
        val ea = FloatArray(n) { i -> if (i == 0 || i == n - 1) 0f else sa[i + 1] - sa[i - 1] }
        var normA = 0.0
        for (v in ea) normA += (v * v).toDouble()
        normA = sqrt(normA)
        if (normA < 1e-3) return null

        val startBin = (w.startMs / 100).toInt()
        val base = startBin - (center + range)
        val len = n + 2 * range
        val sig = FloatArray(len)
        for (c in cues) {
            val s = ((c.s / 100).toInt() - base).coerceIn(0, len)
            val en = (((c.e + 99) / 100).toInt() - base).coerceIn(0, len)
            for (i in s until en) sig[i] = 1f
        }
        val ss = smooth3(sig)
        val es = FloatArray(len) { i -> if (i == 0 || i == len - 1) 0f else ss[i + 1] - ss[i - 1] }
        val ps = DoubleArray(len + 1)
        for (i in 0 until len) ps[i + 1] = ps[i] + (es[i] * es[i]).toDouble()

        val ks = (center - range)..(center + range)
        val sc = FloatArray(2 * range + 1)
        for (k in ks) {
            val off = -k + center + range
            var sumS = 0f
            var sumAS = 0f
            var sumE = 0.0
            for (i in 0 until n) {
                val v = sig[i + off]
                sumS += v
                sumAS += a[i] * v
                sumE += (ea[i] * es[i + off]).toDouble()
            }
            val sMean = sumS / n
            val varS = sMean * (1 - sMean)
            val pear = if (varS < 1e-4f) 0f else (sumAS / n - aMean * sMean) / sqrt(varA * varS)
            val nb = sqrt(ps[off + n] - ps[off])
            val edge = if (nb < 1e-3) 0f else (sumE / (normA * nb)).toFloat()
            sc[k - ks.first] = 0.5f * pear + 0.5f * edge
        }
        var mean = 0.0
        for (v in sc) mean += v
        mean /= sc.size
        var sd = 0.0
        for (v in sc) sd += (v - mean) * (v - mean)
        sd = sqrt(sd / sc.size)
        if (sd < 1e-4) return null

        var best = ks.first
        var bestAdj = Float.NEGATIVE_INFINITY
        for (k in ks) {
            val adj = sc[k - ks.first] - 0.05f * abs(k - center) / range   // mild preference for the current offset
            if (adj > bestAdj) { bestAdj = adj; best = k }
        }
        var atCenter = Float.NEGATIVE_INFINITY
        for (k in (center - 3)..(center + 3)) atCenter = maxOf(atCenter, sc[k - ks.first])
        val z = ((sc[best - ks.first] - mean) / sd).toFloat()
        return Cand(best, sc[best - ks.first], atCenter, z)
    }

    /**
     * Applies an offset only when independent windows agree, the peak is statistically clear, and it beats the
     * current offset. Big jumps (> 30 s / > 60 s) need much more evidence, since the subtitle is usually
     * already roughly right.
     */
    fun decide(cands: List<Cand>, total: Int, centerMs: Long): Outcome {
        val center = (centerMs / 100).toInt()
        val single = total < 2
        val good = cands.filter { it.best > (if (single) 0.15f else 0.08f) && it.z >= (if (single) 4.5f else 3.5f) }
        if (good.isEmpty()) return Outcome(0, 0, 0, total)
        var group: List<Cand> = emptyList()
        for (c in good) {
            val g = good.filter { abs(it.k - c.k) <= 10 }
            if (g.size > group.size) group = g
        }
        if (group.size < (if (single) 1 else 2)) {
            // a single very clear window close to the current offset is accepted too
            val s = good.maxByOrNull { it.z }
            if (s != null && s.z >= 6.5f && s.best > 0.2f && abs(s.k - center) <= 150) group = listOf(s)
            else return Outcome(0, 0, group.size, total)
        }
        val k = group.map { it.k }.sorted()[group.size / 2]
        val shift = abs(k - center)
        val gain = group.map { it.best - it.atCenter }.average()
        if (shift <= 3 || gain < 0.06) return Outcome(2, centerMs, group.size, total)
        if (shift > 600 && group.size < 3) return Outcome(0, 0, group.size, total)
        if (shift > 300 && group.size < 3 && !group.all { it.z >= 6f }) return Outcome(0, 0, group.size, total)
        return Outcome(1, k * 100L, group.size, total)
    }

    fun solveMulti(ws: List<Window>, cues: List<CueParser.C>, centerMs: Long): Outcome {
        if (cues.isEmpty()) return Outcome(0, 0, 0, ws.size)
        val center = (centerMs / 100).toInt()
        return decide(ws.mapNotNull { analyzeWindow(it, cues, center) }, ws.size, centerMs)
    }
}
