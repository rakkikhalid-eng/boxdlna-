package com.rakki.boxdlna

import android.app.Application
import android.content.Context
import java.io.File
import java.io.PrintWriter
import java.io.StringWriter

class App : Application() {
    override fun onCreate() {
        super.onCreate()
        val prev = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            try {
                val sw = StringWriter()
                e.printStackTrace(PrintWriter(sw))
                File(filesDir, "crash.txt").writeText("thread: " + t.name + "\n" + sw.toString())
                getSharedPreferences("box", Context.MODE_PRIVATE).edit().putBoolean("castOff", true).commit()
            } catch (x: Throwable) { }
            prev?.uncaughtException(t, e)
        }
    }
}
