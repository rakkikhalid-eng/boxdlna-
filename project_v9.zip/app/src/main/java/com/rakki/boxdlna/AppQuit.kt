package com.rakki.boxdlna

import android.app.Activity
import android.content.Intent
import android.os.Process

object AppQuit {
    fun quit(a: Activity) {
        try { a.stopService(Intent(a, DlnaService::class.java)) } catch (e: Exception) { }
        a.finishAndRemoveTask()
        Renderer.main.postDelayed({ Process.killProcess(Process.myPid()) }, 500)
    }
}
