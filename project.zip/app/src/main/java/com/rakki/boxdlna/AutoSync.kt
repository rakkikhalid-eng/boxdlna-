package com.rakki.boxdlna

import androidx.media3.common.C
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.audio.BaseAudioProcessor
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.abs
import kotlin.math.sqrt

/**
 * Automatic subtitle sync without any server: the player's PCM audio is measured (10 ms energy bins),
 * turned into a "someone is speaking" signal, then cross-correlated with the "a subtitle is on screen"
 * signal. The offset with the best match is applied.
 */
object AutoSync {
    private val lock = Any()
    private val bins = ArrayList<Float>()
    private var curSum = 0.0
    private var curCnt = 0
    private var binFrames = 480
    private var channels = 2
    private var encoding = C.ENCODING_PCM_16BIT
    private var filt = Filt(48000)

    @Volatile var collecting = false
    @Volatile var pendingRefMs = 0L
    @Volatile var refMs = 0L

    fun begin(posMs: Long) {
        synchronized(lock) { bins.clear(); curSum = 0.0; curCnt = 0 }
        pendingRefMs = posMs
        refMs = posMs
        collecting = true
    }

    fun end(): FloatArray {
        collecting = false
        synchronized(lock) { return bins.toFloatArray() }
    }

    fun binCount(): Int = synchronized(lock) { bins.size }

    val processor: AudioProcessor = object : BaseAudioProcessor() {
        override fun onConfigure(inputAudioFormat: AudioProcessor.AudioFormat): AudioProcessor.AudioFormat {
            encoding = inputAudioFormat.encoding
            channels = maxOf(1, inputAudioFormat.channelCount)
            binFrames = maxOf(1, inputAudioFormat.sampleRate / 100)
            filt = Filt(maxOf(8000, inputAudioFormat.sampleRate))
            return inputAudioFormat
        }

        override fun queueInput(inputBuffer: ByteBuffer) {
            val n = inputBuffer.remaining()
            if (n == 0) return
            if (collecting && encoding == C.ENCODING_PCM_16BIT) {
                try { analyze(inputBuffer.duplicate()) } catch (e: Exception) { }
            }
            val out = replaceOutputBuffer(n)
            out.put(inputBuffer)
            out.flip()
        }

        override fun onFlush() {
            if (collecting) {
                synchronized(lock) { bins.clear(); curSum = 0.0; curCnt = 0 }
                refMs = pendingRefMs
            }
        }
    }

    private fun analyze(b: ByteBuffer) {
        b.order(ByteOrder.LITTLE_ENDIAN)
        val sb = b.asShortBuffer()
        synchronized(lock) {
            while (sb.remaining() >= channels) {
                var acc = 0
                for (i in 0 until channels) acc += sb.get().toInt()
                val m = filt.f(acc.toDouble() / channels / 32768.0)
                curSum += m * m
                curCnt++
                if (curCnt >= binFrames) {
                    bins.add(sqrt(curSum / curCnt).toFloat())
                    curSum = 0.0
                    curCnt = 0
                }
            }
        }
    }

    class Result(val offsetMs: Long, val ok: Boolean)

    /** [bins] are 10 ms RMS values starting at media time [startMs]. Returns the subtitle offset (ms). */
    fun solve(bins: FloatArray, startMs: Long, cues: List<CueParser.C>): Result {
        if (cues.isEmpty() || bins.size < 3000) return Result(0, false)
        // 100 ms speech signal from audio
        val n = bins.size / 10
        val e = FloatArray(n)
        for (i in 0 until n) {
            var s = 0f
            for (j in 0 until 10) s += bins[i * 10 + j]
            e[i] = s / 10f
        }
        val sorted = e.sortedArray()
        val lo = sorted[(n * 0.2).toInt()]
        val hi = sorted[(n * 0.9).toInt().coerceAtMost(n - 1)]
        if (hi - lo < 1e-4f) return Result(0, false)
        val thr = lo + 0.25f * (hi - lo)
        val a = FloatArray(n) { if (e[it] > thr) 1f else 0f }
        val aMean = a.average().toFloat()
        if (aMean < 0.05f || aMean > 0.95f) return Result(0, false)

        // 100 ms subtitle signal covering [start - R, end + R]
        val range = 600 // +-60 s in 100 ms steps
        val startBin = startMs / 100
        val from = startBin - range
        val len = n + 2 * range
        val sig = FloatArray(len)
        for (c in cues) {
            val s = (c.s / 100 - from).toInt().coerceIn(0, len)
            val en = ((c.e + 99) / 100 - from).toInt().coerceIn(0, len)
            for (i in s until en) sig[i] = 1f
        }

        val scores = FloatArray(2 * range + 1)
        for (k in -range..range) {
            // audio bin i (time startBin + i) pairs with subtitle time (startBin + i - k)
            var sumS = 0f
            var sumAS = 0f
            for (i in 0 until n) {
                val v = sig[i - k + range]
                sumS += v
                sumAS += a[i] * v
            }
            val sMean = sumS / n
            scores[k + range] = sumAS - n * aMean * sMean
        }
        var best = 0
        for (i in scores.indices) if (scores[i] > scores[best]) best = i
        var second = Float.NEGATIVE_INFINITY
        for (i in scores.indices) if (abs(i - best) > 10 && scores[i] > second) second = scores[i]
        val ok = scores[best] > 0f && (second <= 0f || scores[best] >= 1.15f * second)
        return Result((best - range) * 100L, ok)
    }

    /** Voice band-pass (about 300-3400 Hz) so music bass and hiss count less than dialogue. */
    class Filt(rate: Int) {
        private val dt = 1.0 / rate
        private val aH = (1.0 / (2 * Math.PI * 300)).let { it / (it + dt) }
        private val aL = dt / ((1.0 / (2 * Math.PI * 3400)) + dt)
        private var px = 0.0
        private var hy = 0.0
        private var ly = 0.0
        fun f(x: Double): Double {
            hy = aH * (hy + x - px)
            px = x
            ly += aL * (hy - ly)
            return ly
        }
    }

    class Window(val startMs: Long, val bins: FloatArray)

    /** status: 0 = not reliable, 1 = offset found, 2 = already in sync. */
    class Outcome(val status: Int, val offsetMs: Long, val agree: Int, val total: Int)

    private class Cand(val k: Int, val best: Float, val atCenter: Float)

    private fun analyzeWindow(w: Window, cues: List<CueParser.C>, center: Int, range: Int): Cand? {
        val bins = w.bins
        val n = bins.size / 10
        if (n < 300) return null
        val e = FloatArray(n)
        for (i in 0 until n) {
            var s = 0f
            for (j in 0 until 10) s += kotlin.math.ln(bins[i * 10 + j] + 1e-4f)
            e[i] = s / 10f
        }
        val sorted = e.sortedArray()
        val lo = sorted[(n * 0.2).toInt()]
        val hi = sorted[(n * 0.9).toInt().coerceAtMost(n - 1)]
        if (hi - lo < 0.3f) return null
        val thr = lo + 0.4f * (hi - lo)
        val raw = FloatArray(n) { if (e[it] > thr) 1f else 0f }
        // median of 3 removes isolated blips
        val a = FloatArray(n) { i ->
            val c = raw[i] + raw.getOrElse(i - 1) { raw[i] } + raw.getOrElse(i + 1) { raw[i] }
            if (c >= 2f) 1f else 0f
        }
        val aMean = a.average().toFloat()
        if (aMean < 0.08f || aMean > 0.92f) return null
        val varA = aMean * (1 - aMean)

        val startBin = (w.startMs / 100).toInt()
        val base = startBin - (center + range)
        val len = n + 2 * range
        val sig = FloatArray(len)
        for (c in cues) {
            val s = ((c.s / 100).toInt() - base).coerceIn(0, len)
            val en = (((c.e + 99) / 100).toInt() - base).coerceIn(0, len)
            for (i in s until en) sig[i] = 1f
        }
        val ks = (center - range)..(center + range)
        val pear = FloatArray(2 * range + 1)
        for (k in ks) {
            var sumS = 0f
            var sumAS = 0f
            for (i in 0 until n) {
                val v = sig[i - k + center + range]
                sumS += v
                sumAS += a[i] * v
            }
            val sMean = sumS / n
            val varS = sMean * (1 - sMean)
            pear[k - ks.first] = if (varS < 1e-4f) 0f else (sumAS / n - aMean * sMean) / sqrt(varA * varS)
        }
        // prefer shifts close to the current offset: small penalty growing with distance
        var best = ks.first
        var bestAdj = Float.NEGATIVE_INFINITY
        for (k in ks) {
            val adj = pear[k - ks.first] - 0.08f * abs(k - center) / range
            if (adj > bestAdj) { bestAdj = adj; best = k }
        }
        var atCenter = Float.NEGATIVE_INFINITY
        for (k in (center - 3)..(center + 3)) atCenter = maxOf(atCenter, pear[k - ks.first])
        return Cand(best, pear[best - ks.first], atCenter)
    }

    /**
     * Several windows of the film are analysed independently; the offset is applied only if at least two agree
     * (or one strong window if the film is short), and only if it beats the current offset clearly.
     */
    fun solveMulti(ws: List<Window>, cues: List<CueParser.C>, centerMs: Long): Outcome {
        if (cues.isEmpty()) return Outcome(0, 0, 0, ws.size)
        val range = 900                        // +-90 s around the current offset
        val center = (centerMs / 100).toInt()
        val cands = ws.mapNotNull { analyzeWindow(it, cues, center, range) }.filter { it.best > 0.10f }
        if (cands.isEmpty()) return Outcome(0, 0, 0, ws.size)
        var group: List<Cand> = emptyList()
        for (c in cands) {
            val g = cands.filter { abs(it.k - c.k) <= 6 }
            if (g.size > group.size) group = g
        }
        val need = if (ws.size >= 2) 2 else 1
        if (group.size < need) return Outcome(0, 0, group.size, ws.size)
        if (ws.size == 1 && group[0].best < 0.22f) return Outcome(0, 0, group.size, ws.size)
        val k = group.map { it.k }.sorted()[group.size / 2]
        val gain = group.map { it.best - it.atCenter }.average()
        if (abs(k - center) <= 3 || gain < 0.04) return Outcome(2, centerMs, group.size, ws.size)
        return Outcome(1, k * 100L, group.size, ws.size)
    }
}
