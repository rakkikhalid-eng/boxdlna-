package com.rakki.boxdlna

import android.animation.ValueAnimator
import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView

/** Short animated splash: logo + app name, with a small English caption underneath. */
class IntroActivity : Activity() {
    private var done = false

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val frame = FrameLayout(this)
        frame.background = GradientDrawable(
            GradientDrawable.Orientation.TL_BR,
            intArrayOf(Color.parseColor("#060A18"), Color.parseColor("#101C45"), Color.parseColor("#1D3A8A"))
        )
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.gravity = Gravity.CENTER

        val logo = LogoView(this)
        logo.alpha = 0f
        logo.scaleX = 0.6f
        logo.scaleY = 0.6f
        logo.waves = 0f
        col.addView(logo, LinearLayout.LayoutParams(dp(240), dp(240)))

        val name = TextView(this)
        name.text = "Box DLNA"
        name.textSize = 40f
        name.setTextColor(Color.WHITE)
        name.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD))
        name.letterSpacing = 0.04f
        name.alpha = 0f
        name.translationY = dp(18).toFloat()
        col.addView(name)

        val cap = TextView(this)
        cap.text = "SMART MEDIA RECEIVER"
        cap.textSize = 13f
        cap.setTextColor(Color.parseColor("#9DB2D8"))
        cap.letterSpacing = 0.3f
        cap.alpha = 0f
        cap.setPadding(0, dp(6), 0, 0)
        col.addView(cap)

        frame.addView(col, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT, Gravity.CENTER))
        setContentView(frame)

        logo.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(750).setInterpolator(OvershootInterpolator(1.4f)).start()
        ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 1000
            startDelay = 300
            interpolator = DecelerateInterpolator()
            addUpdateListener { logo.waves = it.animatedValue as Float }
            start()
        }
        name.animate().alpha(1f).translationY(0f).setStartDelay(550).setDuration(600).start()
        cap.animate().alpha(1f).setStartDelay(900).setDuration(600).start()

        frame.setOnClickListener { next() }
        frame.postDelayed({ next() }, 2600)
    }

    private fun next() {
        if (done) return
        done = true
        startActivity(Intent(this, MainActivity::class.java))
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
        finish()
    }
}
