package com.rakki.boxdlna

import android.content.Context
import org.json.JSONObject
import org.vosk.LibVosk
import org.vosk.LogLevel
import org.vosk.Model
import org.vosk.Recognizer
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.util.zip.ZipInputStream

/**
 * Offline speech recognition (Vosk, small models of about 40 MB) used only to learn *when* people talk in the movie,
 * which is far more reliable than loudness. Nothing leaves the box. The model is downloaded once.
 */
object LocalAsr {
    private val MODELS = mapOf("eng" to "vosk-model-small-en-us-0.15", "fre" to "vosk-model-small-fr-0.22")

    fun enabled(c: Context): Boolean = Cfg.asrLang(c) in MODELS
    private fun modelName(c: Context): String? = MODELS[Cfg.asrLang(c)]
    private fun dir(c: Context): File? = modelName(c)?.let { File(c.filesDir, "vosk/$it") }
    fun installed(c: Context): Boolean = dir(c)?.let { File(it, "am").isDirectory } ?: false

    /** Downloads and unpacks the model for the chosen language. Progress is 0..100 for the download. */
    fun download(c: Context, onProgress: (Int) -> Unit): Boolean {
        val n = modelName(c) ?: return false
        val root = File(c.filesDir, "vosk")
        root.mkdirs()
        val tmp = File(root, "$n.zip.part")
        return try {
            val con = URL("https://alphacephei.com/vosk/models/$n.zip").openConnection() as HttpURLConnection
            con.connectTimeout = 15000
            con.readTimeout = 30000
            con.instanceFollowRedirects = true
            val total = con.contentLengthLong
            con.inputStream.use { ins ->
                tmp.outputStream().use { out ->
                    val buf = ByteArray(64 * 1024)
                    var done = 0L
                    var last = -1
                    while (true) {
                        val r = ins.read(buf)
                        if (r < 0) break
                        out.write(buf, 0, r)
                        done += r
                        if (total > 0) {
                            val pc = (done * 100 / total).toInt()
                            if (pc != last) { last = pc; onProgress(pc) }
                        }
                    }
                }
            }
            ZipInputStream(tmp.inputStream().buffered()).use { z ->
                var e = z.nextEntry
                while (e != null) {
                    val f = File(root, e.name)
                    if (!f.canonicalPath.startsWith(root.canonicalPath + File.separator)) throw SecurityException("bad zip entry")
                    if (e.isDirectory) f.mkdirs() else { f.parentFile?.mkdirs(); f.outputStream().use { o -> z.copyTo(o) } }
                    e = z.nextEntry
                }
            }
            tmp.delete()
            installed(c)
        } catch (e: Throwable) {
            tmp.delete()
            CmdLog.add("model download failed: " + (e.message ?: e.javaClass.simpleName).take(120))
            false
        }
    }

    private var model: Model? = null
    private var modelPath = ""

    @Synchronized
    private fun load(c: Context): Model? {
        val d = dir(c) ?: return null
        if (model != null && modelPath == d.absolutePath) return model
        try { model?.close() } catch (e: Throwable) { }
        LibVosk.setLogLevel(LogLevel.WARNINGS)
        model = Model(d.absolutePath)
        modelPath = d.absolutePath
        return model
    }

    /** Frees the ~300 MB the model uses once the sync is over. */
    @Synchronized
    fun release() {
        try { model?.close() } catch (e: Throwable) { }
        model = null
        modelPath = ""
    }

    /** 100 ms speech presence for a 16 kHz mono window, or null when too few words were recognised. */
    fun speechMask(c: Context, pcm: ShortArray, windowMs: Long): FloatArray? {
        return try {
            val m = load(c) ?: return null
            val rec = Recognizer(m, 16000f)
            rec.setWords(true)
            val n = (windowMs / 100).toInt()
            val mask = FloatArray(n)
            var words = 0
            fun take(json: String) {
                val arr = JSONObject(json).optJSONArray("result") ?: return
                for (i in 0 until arr.length()) {
                    val w = arr.getJSONObject(i)
                    val s = (w.optDouble("start", 0.0) * 10).toInt().coerceIn(0, n)
                    val e = (w.optDouble("end", 0.0) * 10).toInt().coerceIn(0, n)
                    for (k in s until e) mask[k] = 1f
                    words++
                }
            }
            var off = 0
            while (off < pcm.size) {
                val len = minOf(4000, pcm.size - off)
                val buf = pcm.copyOfRange(off, off + len)
                if (rec.acceptWaveForm(buf, len)) take(rec.result)
                off += len
            }
            take(rec.finalResult)
            rec.close()
            // short pauses between words belong to the same line of dialogue
            var lastOne = -100
            for (k in 0 until n) {
                if (mask[k] == 1f) {
                    if (k - lastOne in 2..8) for (j in lastOne + 1 until k) mask[j] = 1f
                    lastOne = k
                }
            }
            CmdLog.add("ASR: $words words recognised")
            if (words < 15) null else mask
        } catch (e: Throwable) {
            CmdLog.add("ASR error: " + (e.message ?: e.javaClass.simpleName).take(120))
            null
        }
    }
}
