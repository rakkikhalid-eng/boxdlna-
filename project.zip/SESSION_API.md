# Box DLNA – `/session` API

A sender app (yours or anyone's) can start a video on the box with every quality and subtitle it knows about.
The box shows them all in the player (bottom buttons: Quality / Subtitles / Audio) and applies the user's saved
preferences (preferred audio language, preferred subtitle language, maximum quality) automatically.

## Start a video

`POST http://<box-ip>:<port>/session` with a JSON body (the port is shown on the app's home screen):

```json
{
  "title": "Reacher",
  "year": "2022",
  "season": 1,
  "episode": 2,
  "play": true,
  "startMs": 0,
  "sources": [
    { "url": "http://.../1080.m3u8", "label": "1080p", "height": 1080 },
    { "url": "http://.../720.m3u8",  "label": "720p",  "height": 720 }
  ],
  "subtitles": [
    { "url": "http://.../fr.srt", "label": "Français", "lang": "fr" },
    { "url": "http://.../ar.srt", "label": "العربية",  "lang": "ar" }
  ]
}
```

* `sources` – the first one is played; the others appear in the *Quality* list (the position is kept when switching).
  A single HLS/DASH master playlist is enough: its own variants appear in the same list.
* `subtitles` – the first is the sender's default subtitle, the others appear in the *Subtitles* list with their language.
  Embedded tracks of the stream (HLS/DASH) are listed too.
* `season` / `episode` / `year` / `title` are also used to search subtitles on OpenSubtitles.

## Other endpoints

| Method | Path | What |
|---|---|---|
| GET | `/session` | sources, subtitles and preferences currently known |
| GET | `/status` | playback state, position, subtitle offset |
| GET | `/sub/offset?ms=1200` or `?delta=-500` | subtitle delay, live |
| GET | `/sub/enable?v=0\|1` | show / hide subtitles |
| GET | `/sub/autosync` | start the automatic subtitle sync |
| GET | `/log` | last commands received |

## AI sync

In the app's home screen, *AI sync* accepts an API key for any OpenAI-compatible `/audio/transcriptions`
endpoint (OpenAI `whisper-1`, Groq `whisper-large-v3-turbo` with base URL `https://api.groq.com/openai/v1`, ...).
Only the *times* of recognised speech are used, so it works for any language.
