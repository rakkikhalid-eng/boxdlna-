package com.rakki.boxdlna

import java.text.SimpleDateFormat
import java.util.ArrayDeque
import java.util.Date
import java.util.Locale

/** Ring buffer of the commands received from the sender app (for diagnosing sender behaviour). */
object CmdLog {
    private val lines = ArrayDeque<String>()
    private val fmt = SimpleDateFormat("HH:mm:ss.SSS", Locale.US)

    @Synchronized
    fun add(s: String) {
        lines.addLast(fmt.format(Date()) + "  " + s.replace('\n', ' '))
        while (lines.size > 80) lines.removeFirst()
    }

    private val net = ArrayDeque<String>()

    @Synchronized
    fun addNet(s: String) {
        net.addLast(fmt.format(Date()) + "  " + s.replace('\n', ' '))
        while (net.size > 80) net.removeFirst()
    }

    @Synchronized
    fun dumpNet(max: Int = 20): String = net.toList().takeLast(max).joinToString("\n")

    @Synchronized
    fun dump(max: Int = 40): String {
        val l = lines.toList()
        return l.takeLast(max).joinToString("\n")
    }
}
