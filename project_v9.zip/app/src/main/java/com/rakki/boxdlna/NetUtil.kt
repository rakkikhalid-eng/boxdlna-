package com.rakki.boxdlna

import java.net.Inet4Address
import java.net.NetworkInterface
import java.util.Collections

object NetUtil {
    fun local(): Pair<String, NetworkInterface>? {
        val raw = try { NetworkInterface.getNetworkInterfaces() } catch (e: Exception) { null } ?: return null
        val all = Collections.list(raw)
        val sorted = all
            .filter { try { it.isUp && !it.isLoopback } catch (e: Exception) { false } }
            .sortedBy { if (it.name.startsWith("eth") || it.name.startsWith("wlan")) 0 else 1 }
        for (ni in sorted) {
            for (a in Collections.list(ni.inetAddresses)) {
                if (a is Inet4Address && a.isSiteLocalAddress) {
                    val h = a.hostAddress
                    if (h != null) return Pair(h, ni)
                }
            }
        }
        return null
    }
}
