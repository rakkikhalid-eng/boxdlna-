package com.rakki.boxdlna

import android.content.Context
import android.content.Intent
import android.os.Handler
import android.os.Looper

object Renderer {
    val main = Handler(Looper.getMainLooper())

    @Volatile var uri = ""
    @Volatile var meta = ""
    @Volatile var subUrl: String? = null
    @Volatile var state = "NO_MEDIA_PRESENT"
    @Volatile var posMs = 0L
    @Volatile var durMs = 0L
    @Volatile var wantPlay = false
    @Volatile var startMs = 0L
    @Volatile var activity: PlayerActivity? = null
    @Volatile var manual: SubtitleLoader.Sub? = null
    @Volatile var manualUri = ""
    @Volatile var onChange: (() -> Unit)? = null
    @Volatile var subOffsetMs = 0L
    @Volatile var subsEnabled = true
    @Volatile var cueCount = 0
    @Volatile var ovSeason = -1
    @Volatile var ovEpisode = -1
    @Volatile var ovYear: String? = null
    @Volatile var results: List<SubSearch.Res> = emptyList()
    @Volatile var ignoreStop = false
    @Volatile var resumeKey = ""
    @Volatile var resumePos = 0L
    @Volatile var resumeAt = 0L

    /** Same video even if the sender appends a changing token to the URL. */
    fun key(u: String): String = u.substringBefore('?')

    fun rememberResume(pos: Long) {
        if (uri.isNotEmpty() && pos > 5000) { resumeKey = key(uri); resumePos = pos; resumeAt = System.currentTimeMillis() }
    }

    fun changed() { onChange?.invoke() }

    fun setUri(u: String, m: String) {
        val newSub = extractSubtitle(m)
        // Same video, player already running: only the subtitle changed -> swap it live, no restart.
        CmdLog.add("SetURI " + u.take(200) + " | sub=" + (newSub ?: "-") + " | meta=" + m.take(500))
        if (u.isNotEmpty() && key(u) == key(uri) && activity != null) {
            uri = u
            meta = m
            if (newSub != subUrl) {
                subUrl = newSub
                manual = null
                manualUri = ""
                main.post { activity?.reloadSubs() }
            }
            changed()
            return
        }
        uri = u; meta = m
        subUrl = newSub
        posMs = 0; durMs = 0; wantPlay = false; startMs = 0
        // the sender re-sent the same video moments after it was closed (e.g. subtitle toggle): resume where it was
        if (u.isNotEmpty() && key(u) == resumeKey && System.currentTimeMillis() - resumeAt < 20_000) {
            startMs = resumePos
            CmdLog.add("resume at " + resumePos + " ms")
        }
        resumeKey = ""
        subOffsetMs = 0
        ovSeason = -1; ovEpisode = -1; ovYear = null
        if (u.isNotEmpty() && manualUri == "*") manualUri = u
        state = if (u.isEmpty()) "NO_MEDIA_PRESENT" else "STOPPED"
        main.post { activity?.player?.pause() }
        changed()
    }

    fun applyManual(s: SubtitleLoader.Sub) {
        manual = s
        subOffsetMs = 0
        subsEnabled = true
        manualUri = if (uri.isNotEmpty() && activity != null) uri else "*"
        main.post { activity?.reloadSubs() }
    }

    fun effectiveManual(): SubtitleLoader.Sub? = manual?.takeIf { manualUri == uri }

    fun signature(): String = uri + "|" + (effectiveManual()?.file?.name ?: subUrl ?: "")

    fun play(ctx: Context) {
        if (uri.isEmpty()) return
        wantPlay = true
        if (state != "PLAYING") { state = "TRANSITIONING"; changed() }
        val a = activity
        if (a != null) main.post { a.onPlayRequest() }
        try {
            ctx.startActivity(Intent(ctx, PlayerActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (e: Exception) { }
    }

    fun pause() { main.post { activity?.player?.pause() } }

    fun stop() {
        wantPlay = false
        state = if (uri.isEmpty()) "NO_MEDIA_PRESENT" else "STOPPED"
        posMs = 0
        main.post { activity?.finish() }
        changed()
    }

    fun seek(ms: Long) {
        main.post {
            val p = activity?.player
            if (p != null) p.seekTo(ms) else startMs = ms   // player not created yet: use as start position
        }
    }
}
